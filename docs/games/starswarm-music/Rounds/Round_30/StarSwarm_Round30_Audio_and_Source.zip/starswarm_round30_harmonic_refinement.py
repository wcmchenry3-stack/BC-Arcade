"""Round 30: harmonically refined electromagnetic score based on Round 29B.
Original synthesis from silence, with voice-leading and sideband adjustments.
No licensed sources, prior audio recordings or samples are used.
"""
from pathlib import Path
import argparse
import subprocess
import numpy as np
from scipy.signal import butter, sosfilt

SR=24000
DUR=26.0
N=int(SR*DUR)
OUT=Path(__file__).resolve().parent

def hz(n): return 440*2**((n-69)/12)
def ss(z):
    z=np.clip(z,0.,1.)
    return z*z*(3-2*z)

def render(variant):
    rng=np.random.default_rng(2804)
    score=np.zeros((2,N),dtype=np.float32)
    def voice(midi,start,duration,volume,kind='field',pan=0.,attack=.12,release=.42,seed=0,drift=0):
        s=max(0,int(start*SR)); e=min(N,int((start+duration)*SR))
        if e<=s:return
        t=np.arange(e-s,dtype=np.float64)/SR
        cents=2.5*np.sin(2*np.pi*(.28+seed*.008)*t+seed)+1.7*np.sin(2*np.pi*.84*t+seed*.2)
        ph=2*np.pi*np.cumsum(hz(midi)*2**(cents/1200)/SR)+seed*.3
        if kind=='field':
            x=.80*np.sin(ph)+.29*np.sin(2*ph+.21)+.10*np.sin(3.003*ph+.7)+.045*np.sin(4.07*ph+.32)
        elif kind=='coil':
            x=.80*np.sin(ph)+.24*np.sin(2.005*ph)+.11*np.sin(3.02*ph+.35)+.045*np.sin(5.08*ph)
        elif kind=='sub':
            x=np.sin(ph)+.28*np.sin(2*ph+.3)+.14*np.sin(3*ph+.6)
        elif kind=='aether':
            x=.67*np.sin(ph)+.19*np.sin(1.5*ph+.1)+.14*np.sin(2.41*ph+.4)
        elif kind=='signal':
            # Evolving inharmonic sidebands and spacious sine core, not horn/bowed solo.
            mod=.65*np.sin(ph*.75+np.sin(2*np.pi*.31*t)*.22)
            x=.88*np.sin(ph+mod)+.13*np.sin(ph*1.508+.3)+.055*np.sin(ph*2.09+.5)
            x*=.89+.11*np.sin(2*np.pi*.61*t+seed*.3)**2
        else: raise ValueError(kind)
        env=ss(t/max(.02,attack))*ss((duration-t)/max(.06,release))
        if kind in ('field','coil'):
            env*=.80+.20*np.sin(2*np.pi*(.35+seed*.011)*t+.3)**2
        env*=1+drift*(t/max(duration,.001)-.5)
        y=(volume*x*env).astype(np.float32)
        ang=np.pi*(pan+1)/4
        score[0,s:e]+=np.cos(ang)*y
        score[1,s:e]+=np.sin(ang)*y

    harmony=[
        (0,5.5,38,[57,62,65,69,74]),       # D minor, stable chord tones
        (5.1,5.6,34,[58,62,65,69,74]),     # Bbmaj7, common tones D/F/A
        (10.2,5.8,31,[55,58,62,67,74]),    # Gm7: natural shift through F and D
        (15.8,5.2,33,[57,62,64,67,76]),    # A7sus9, distinct controlled suspension
        (20.6,5.4,38,[57,62,65,69,74]),    # Dm arrival, no triumphant cadence
    ]
    for j,(start,dur,root,tones) in enumerate(harmony):
        voice(root,start,dur+.18,.047,'sub',-.15,attack=.10 if j else .18,release=.52,seed=10+j)
        for k,p in enumerate(tones):
            offset=[.00,.14,.27,.51,.72][k]
            voice(p,start+offset,max(.1,dur-offset),.0147 if k<3 else .0112,
                  'field' if k%2==0 else 'coil',pan=-.65+.3*k,
                  attack=.16 if k<3 else .38,release=.72,seed=21+j*9+k,drift=.12)
        for k,(off,iv) in enumerate([(1.24,7),(2.38,12),(3.48,7),(4.31,12)]):
            if off<dur-.35:
                voice(root+iv,start+off,.75,.018,'coil',pan=.35 if k%2 else -.3,
                      attack=.045,release=.24,seed=80+j*5+k)

    # Single controlled difference: original melody removed in A, replaced in B.
    notes=[(.12,74,1.6), (1.67,76,.72),(2.44,77,1.6),(4.2,76,.65),
           (5.30,74,1.45),(6.9,72,.9),(8.02,74,1.55),(9.78,77,.9),
           (10.77,79,1.45),(12.42,77,.7),(13.24,74,1.55),
           (15.99,76,1.34),(17.87,74,.82),(18.92,79,1.22),
           (20.95,77,1.06),(22.22,76,.60),(23.05,74,1.78)]
    if variant=='C':
        for i,(st,p,d) in enumerate(notes):
            voice(p,st,d+.10,.017 if i%3 else .020,'signal',
                  pan=.29 if i%2 else -.31,attack=.14,release=.30,seed=120+i)
            if i in (2,6,10,13,16):
                voice(p-12,st+.26,min(1.2,d+.10),.0048,'aether',
                      pan=.5 if i%2 else -.5,attack=.18,release=.27,seed=210+i)

    for k,(st,dur,amp) in enumerate([(.15,3.2,.0032),(5.25,2.4,.0028),(10.1,2.7,.0035),(15.9,3.6,.003),(21.0,2.4,.003)]):
        s=int(st*SR); e=min(N,int((st+dur)*SR)); t=np.arange(e-s)/SR
        white=rng.normal(0,1,len(t))
        sos=butter(3,[650+130*k,2100+140*k],fs=SR,btype='bandpass',output='sos')
        band=sosfilt(sos,white)
        band=band/(np.std(band)+1e-8)
        env=ss(t/(dur*.48))*ss((dur-t)/(dur*.39))
        for ch in range(2): score[ch,s:e]+=amp*band*env*(.85 if ch==k%2 else .6)

    time=np.arange(N)/SR
    macro=(.55+.45*ss((time-.18)/2.15))*(.94+.06*np.sin(2*np.pi*time/9.3))
    macro*=ss((DUR-time)/.30)
    score*=macro[None,:]
    dry=score.copy()
    for ch in range(2):
        for delay,gain in [(0.11,.11),(0.39,.073),(0.81,.038)]:
            lag=int((delay+.035*ch)*SR)
            score[ch,lag:]+=gain*dry[1-ch,:-lag]
    return score

if __name__=='__main__':
    rendered={'C':render('C')}
    # One common scaling factor: differences in musical weight are preserved.
    peak=max(np.max(np.abs(x)) for x in rendered.values())
    gain=.83/max(peak,.0001)
    for variant,signal in rendered.items():
        name='starswarm-round30-C-harmonic-electromagnetic.mp3'
        target=OUT/name
        cmd=['ffmpeg','-y','-loglevel','error','-f','f32le','-ar',str(SR),
             '-ac','2','-i','pipe:0','-c:a','libmp3lame','-b:a','128k',str(target)]
        subprocess.run(cmd,input=np.ascontiguousarray((signal*gain).T,dtype='<f4').tobytes(),check=True)
        print(name,target.stat().st_size,'bytes')
