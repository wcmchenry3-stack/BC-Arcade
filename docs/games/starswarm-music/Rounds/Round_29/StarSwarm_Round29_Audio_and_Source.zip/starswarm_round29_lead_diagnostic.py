"""Round 29 A/B isolation test of Round 28's strong later musical foundation.

A = original backing ensemble without the exposed upper melodic lead.
B = same backing plus the same note sequence revoiced as inharmonic FM-like signal,
    avoiding the exposed Renaissance/fantasy-esque tone.
No source recording or third-party samples used. Deterministic synthesis.
"""
from pathlib import Path
import argparse
import subprocess
import numpy as np
from scipy.signal import butter, sosfilt

SR=24000
DUR=22.0
N=int(SR*DUR)
OUT=Path(__file__).resolve().parent

def hz(n): return 440*2**((n-69)/12)
def ss(z):
    z=np.clip(z,0.,1.)
    return z*z*(3-2*z)

def render(variant):
    rng=np.random.default_rng(2804)
    score=np.zeros((2,N),dtype=np.float32)
    def voice(midi,start,duration,volume,kind='field',pan=0.,attack=.12,release=.42,seed=0,drift=0):
        s=max(0,int(start*SR)); e=min(N,int((start+duration)*SR))
        if e<=s:return
        t=np.arange(e-s,dtype=np.float64)/SR
        cents=2.5*np.sin(2*np.pi*(.28+seed*.008)*t+seed)+1.7*np.sin(2*np.pi*.84*t+seed*.2)
        ph=2*np.pi*np.cumsum(hz(midi)*2**(cents/1200)/SR)+seed*.3
        if kind=='field':
            x=.78*np.sin(ph)+.31*np.sin(2*ph+.21)+.17*np.sin(3.013*ph+.7)+.12*np.sin(4.17*ph+.32)
        elif kind=='coil':
            x=.78*np.sin(ph)+.27*np.sin(2.015*ph)+.17*np.sin(2.97*ph+.35)+.11*np.sin(5.28*ph)
        elif kind=='sub':
            x=np.sin(ph)+.28*np.sin(2*ph+.3)+.14*np.sin(3*ph+.6)
        elif kind=='aether':
            x=.67*np.sin(ph)+.19*np.sin(1.5*ph+.1)+.14*np.sin(2.41*ph+.4)
        elif kind=='signal':
            # Evolving inharmonic sidebands and spacious sine core, not horn/bowed solo.
            mod=1.45*np.sin(ph*.739+np.sin(2*np.pi*.37*t)*.34)
            x=.66*np.sin(ph+mod)+.22*np.sin(ph*1.613+.3)+.10*np.sin(ph*2.37+.5)
            x*=.78+.22*np.sin(2*np.pi*.74*t+seed*.3)**2
        else: raise ValueError(kind)
        env=ss(t/max(.02,attack))*ss((duration-t)/max(.06,release))
        if kind in ('field','coil'):
            env*=.80+.20*np.sin(2*np.pi*(.35+seed*.011)*t+.3)**2
        env*=1+drift*(t/max(duration,.001)-.5)
        y=(volume*x*env).astype(np.float32)
        ang=np.pi*(pan+1)/4
        score[0,s:e]+=np.cos(ang)*y
        score[1,s:e]+=np.sin(ang)*y

    harmony=[
        (0,5.5,38,[57,62,65,69,76]),
        (5.1,5.6,34,[57,62,65,70,76]),
        (10.2,5.8,31,[55,58,62,65,74]),
        (15.8,6.2,33,[55,57,62,64,70]),
    ]
    for j,(start,dur,root,tones) in enumerate(harmony):
        voice(root,start,dur+.18,.047,'sub',-.15,attack=.10 if j else .18,release=.52,seed=10+j)
        for k,p in enumerate(tones):
            offset=[.00,.14,.27,.51,.72][k]
            voice(p,start+offset,max(.1,dur-offset),.0147 if k<3 else .0112,
                  'field' if k%2==0 else 'coil',pan=-.65+.3*k,
                  attack=.16 if k<3 else .38,release=.72,seed=21+j*9+k,drift=.12)
        for k,(off,iv) in enumerate([(1.24,7),(2.38,12),(3.48,7),(4.31,10)]):
            if off<dur-.35:
                voice(root+iv,start+off,.75,.018,'coil',pan=.35 if k%2 else -.3,
                      attack=.045,release=.24,seed=80+j*5+k)

    # Single controlled difference: original melody removed in A, replaced in B.
    notes=[(.12,74,1.6), (1.67,76,.72),(2.44,77,1.6),(4.2,76,.65),
           (5.30,74,1.45),(6.9,72,.9),(8.02,74,1.55),(9.78,77,.9),
           (10.77,79,1.45),(12.42,77,.7),(13.24,74,1.55),
           (15.99,76,1.6),(17.87,74,.94),(18.92,77,1.7)]
    if variant=='B':
        for i,(st,p,d) in enumerate(notes):
            voice(p,st,d+.22,.018 if i%3 else .021,'signal',
                  pan=.35 if i%2 else -.37,attack=.24,release=.45,seed=120+i)
            if i in (2,6,10,13):
                voice(p-12,st+.22,min(1.6,d+.20),.009,'aether',
                      pan=.5 if i%2 else -.5,attack=.18,release=.35,seed=210+i)

    for k,(st,dur,amp) in enumerate([(.15,3.2,.0035),(5.25,2.4,.003),(10.1,2.7,.0038),(15.9,3.6,.003)]):
        s=int(st*SR); e=min(N,int((st+dur)*SR)); t=np.arange(e-s)/SR
        white=rng.normal(0,1,len(t))
        sos=butter(3,[650+130*k,2100+140*k],fs=SR,btype='bandpass',output='sos')
        band=sosfilt(sos,white)
        band=band/(np.std(band)+1e-8)
        env=ss(t/(dur*.48))*ss((dur-t)/(dur*.39))
        for ch in range(2): score[ch,s:e]+=amp*band*env*(.85 if ch==k%2 else .6)

    time=np.arange(N)/SR
    macro=(.55+.45*ss((time-.18)/2.15))*(.94+.06*np.sin(2*np.pi*time/9.3))
    macro*=ss((DUR-time)/.30)
    score*=macro[None,:]
    dry=score.copy()
    for ch in range(2):
        for delay,gain in [(0.11,.11),(0.39,.073),(0.81,.038)]:
            lag=int((delay+.035*ch)*SR)
            score[ch,lag:]+=gain*dry[1-ch,:-lag]
    return score

if __name__=='__main__':
    rendered={v:render(v) for v in 'AB'}
    # One common scaling factor: differences in musical weight are preserved.
    peak=max(np.max(np.abs(x)) for x in rendered.values())
    gain=.83/max(peak,.0001)
    for variant,signal in rendered.items():
        name=('starswarm-round29-A-without-lead.mp3' if variant=='A'
              else 'starswarm-round29-B-electromagnetic-lead.mp3')
        target=OUT/name
        cmd=['ffmpeg','-y','-loglevel','error','-f','f32le','-ar',str(SR),
             '-ac','2','-i','pipe:0','-c:a','libmp3lame','-b:a','128k',str(target)]
        subprocess.run(cmd,input=np.ascontiguousarray((signal*gain).T,dtype='<f4').tobytes(),check=True)
        print(name,target.stat().st_size,'bytes')
