# Star Swarm Round 44 — Ambient Long-form Foundation

**Creative audition only — owner review pending.** Seven minutes of original, foundation-only electronic ambient score extending the accepted Round 42.8B sound palette. No approved sci-fi signature effects and no source third-party recordings.

- `starswarm-round44-seven-minute-ambient-foundation.mp3`: 420.048 s, 24 kHz stereo MP3 128 kbps, 6,721,196 bytes, -23.0 LUFS integrated, 6.5 LU LRA, -9.5 dBTP. It has opening and closing fades and **is not yet a seamless loop** or a production master.
- `starswarm_round44_ambient_longform.py`: self-contained, deterministic original music generator; depends on numpy, scipy, soundfile, ffmpeg. Recreates WAV and MP3 from scratch.

## Developmental map (approximate, not time-locked gameplay events)

| Time | Music |
|---|---|
| 0:00–0:59.5 | Persistent horizon: established E drone, wide pads and sparse expressive lead |
| 0:59.5–1:59 | Spectral expansion: higher suspensions and renewed movement |
| 1:59–2:58.5 | Dark current: lower register, diminished density, still-moving drone |
| 2:58.5–3:58 | Undercurrent: changed center and subtle rising brightness |
| 3:58–4:57.5 | New pressure: stronger suspended tension, sparse expressive accents |
| 4:57.5–5:57 | Distant resolve: softer, darker movement without full cadence |
| 5:57–7:00 | Return without cadence: recontextualized opening-family textures, transition to ending |

The seven 63-second **different** harmonic/melodic regions overlap with 3.5-second equal-power blends; they are related by ambient vocabulary rather than repeating the same one-minute waveform. The score deliberately places the pads/drone ahead of the sparse monophonic lead. The opening and ending have fades rather than a validated loop seam. These are development *regions*, not fixed chapters to replay.

## What to listen for

Does the seven-minute adaptation preserve the Round 42.8B character? Does it avoid the mournful/ceremonial foreground and maintain a subtly driving, low-fatigue arcade bed across darker and brighter passages? Are the changes substantial enough to prevent monotony without distracting from weapons and gameplay? Any passage that stands out as too solemn or too dramatic?

**Not yet done:** Owner audition/approval, signature-sound orchestration, live gameplay SFX mix, high-resolution final render, loudness master, codec loop validation, safe re-entry points, or replacement of licensed source audio in the actual game.

**SHA-256**
- MP3: `0e7e10a3a60d3825a2b60ce75789d9889c20b350108bb1158329275cb032a14d`
- Generator: `cd0567b4b9502b2887d5470aa1666fff9205351d3626f1edfdb0a9053ec3e854`

Music epic #3635; audition tracking #3642; existing draft PR #3734.
