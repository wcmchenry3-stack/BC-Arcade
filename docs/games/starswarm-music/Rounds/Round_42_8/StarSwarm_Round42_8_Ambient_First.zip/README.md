# Round 42.8 — Ambient First (A/B listening test)

**Status:** Owner audition pending. No game assets changed.

- A: Round 42.7B, unchanged reference.
- B: New, original procedural foundation-only synthesis based on the Round 42.7 generator.
- Both: 60.048 sec, 24 kHz stereo, 128 kbps MP3, approximately -23.0 LUFS.

## Musical hypothesis

The owner considers 42.7 a giant step in the right direction but notes that its expressive, organ-adjacent electronic lead is still too emotionally foregrounded and choral/ceremonial. This B test changes the listening hierarchy: the suspended cosmic drones and swirling pads now dominate while the warm monophonic lead appears only in three phrases, receding between them. Harmonic arrivals remain soft and open. Very quiet band-limited spectral grain animates the drone without becoming a signature feature. The melody is reduced in both occurrence and level, not deleted.

**No approved signature elements** (astronomical rise, Shepherd descent, Gathering Swarm Chorus, EM Choir, robotic signals) are included. This is not a seven-minute composition or final mix, loop or gameplay mastering test.

## Owner's listening questions

1. Can the music now sit behind continuous gameplay instead of demanding emotional foreground attention?
2. Does the ambient bed remain alive without the prominent lead?
3. Is the lead still recognizable and welcome when it briefly appears, or has it become too faint?
4. Is the sci-fi atmosphere closer to BG-1/2/3 without becoming static or relaxation music?

The Python script runs with numpy/scipy/soundfile/ffmpeg, synthesizing independently without loading or sampling any prior audio. It was adapted from the original Round 42.7 synthesis source. The A MP3 is the unchanged Round 42.7B reference.

See existing draft PR #3734, music epic #3635, audition issue #3642. ZIP is a ChatGPT deliverable and may require separate upload to the existing PR branch; do not treat its binary contents as already committed.
