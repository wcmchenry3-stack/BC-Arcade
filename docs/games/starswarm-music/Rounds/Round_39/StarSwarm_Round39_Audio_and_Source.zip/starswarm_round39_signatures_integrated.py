"""Round 39: integrate project-original foreground signatures with Round 38 score.
No original Pixabay recordings or copyrighted melodies used as source input.
Dependencies: Round 38 MP3 and original project-owned Round 18/19/20 generators.
This reconstruction renders signature layers *without* their earlier experimental bed,
so the Round 38 composition remains the only underlying musical bed.
"""
from pathlib import Path
import subprocess, numpy as np

ROOT=Path(__file__).resolve().parent
SR=24000; DUR=90.0; N=int(SR*DUR)

def decode(p):
    data=subprocess.run(['ffmpeg','-v','error','-i',str(p),'-ar',str(SR),'-ac','2','-f','f32le','-'],capture_output=True,check=True).stdout
    return np.frombuffer(data,dtype='<f4').reshape(-1,2).T.copy()

def sm(q):
    q=np.clip(q,0,1); return q*q*(3-2*q)

def original_stem(filename, end_marker, patch, expression):
    source=(ROOT/filename).read_text()
    source=source.split(end_marker,1)[0]
    if patch not in source: raise ValueError('Could not find expected source patch in '+filename)
    source=source.replace(patch,'src=np.zeros((2,N+120*SR),dtype=np.float32)' if patch.startswith('src=') else 'old=np.zeros((2,N+120*SR),dtype=np.float32)')
    # Original generator expects a per-source local SRC interval, but it is now silence.
    env={'__name__':'round39_stems','__file__':str(ROOT/filename)}
    exec(compile(source,str(ROOT/filename),'exec'),env)
    return np.array(eval(expression,env),dtype=np.float32,copy=True)

bed=decode(ROOT/'starswarm-round38-ninety-second-development.mp3')[:,:N]
assert bed.shape==(2,N)
# For the approved signals and rises, source generators are executed with an all-zero
# contextual bed to extract the actual additive signal, not old music layers.
astro=original_stem('starswarm_round20_spotlight_signals.py','A,B=rise(),signals()',"src=decode(P/'starswarm-round17-A-electromagnetic-expansion.mp3')",'rise()')
signals=original_stem('starswarm_round20_spotlight_signals.py','A,B=rise(),signals()',"src=decode(P/'starswarm-round17-A-electromagnetic-expansion.mp3')",'signals()')
chorus_a=original_stem('starswarm_round18_foreground_chorus.py',"a=build('gathering')", "old=decode(P/'starswarm-round17-A-electromagnetic-expansion.mp3')", "build('gathering')")
chorus_b=original_stem('starswarm_round18_foreground_chorus.py',"a=build('gathering')", "old=decode(P/'starswarm-round17-A-electromagnetic-expansion.mp3')", "build('electromagnetic')")
organ=original_stem('starswarm_round19_remaining_colors.py','a=astronomical();b=haunting();c=lurking()', "src=decode(P/'starswarm-round17-A-electromagnetic-expansion.mp3')", 'haunting()')

# A recognizable, more prevalent signature palette without effect-soup.
# Each event occupies its own foreground window, with an unobtrusive underscore
# that briefly retreats for the strongest astro/chorus gestures.
out=bed.copy().astype(np.float64)
plan=[]
def add(name,src,src_start,dst_start,length,level=.7,fade_in=2,fade_out=3,duck=.15):
    source=src[:,int(src_start*SR):int((src_start+length)*SR)]
    start=int(dst_start*SR);end=min(N,start+source.shape[1]);source=source[:,:end-start]
    t=np.arange(end-start,dtype=np.float64)/SR
    w=sm(t/fade_in)*sm((len(t)/SR-t)/fade_out)
    # In context, crossfade the foreground into the EXISTING foundation instead of
    # replacing it with its old synthetic demo backing.
    out[:,start:end]*=(1-duck*w)[None,:]
    out[:,start:end]+=level*source*w[None,:]
    plan.append(dict(name=name,start=round(dst_start,1),end=round(end/SR,1),level=level,duck=duck))

# Three different types of musical identity return across the 90s; the underlying
# 90s score retains its own genuine melodic/harmonic development.
add('astronomical rise',astro,9.0,8.0,20.5,.52,3,4,.46)  # clear approach / musical return
add('robotic signal sequence',signals,13.0,28.0,14.5,.62,2,2,.22)
add('gathering swarm chorus',chorus_a,10.0,42.0,23.0,.53,4,5,.34)
add('distant organ color',organ,13.0,65.0,15.0,.58,3,3,.06)

# Quiet and clearly separate downward Shepard illusion, preserving the same core
# descending-frequency architecture from the earlier original generator.
def shepard(start,duration,amp=.0085,rate=.13,base=245):
    i=int(start*SR); j=min(N,int((start+duration)*SR))
    t=np.arange(j-i,dtype=np.float64)/SR
    layer=np.zeros((2,j-i),dtype=np.float64)
    for octv in range(-3,7):
        freq=base*np.exp2(octv-rate*t)
        weight=np.exp(-.5*(np.log2(np.maximum(freq,1)/410)/.9)**2)
        for ch in range(2):
            phase=np.cumsum(freq*(1+.00045*ch))*(2*np.pi/SR)+octv*.93+ch*.48
            layer[ch]+=weight*np.sin(phase)
    env=sm(t/2.3)*sm((duration-t)/3.0)
    out[:,i:j]+=amp*layer*env[None,:]
    plan.append(dict(name='descending Shepard tone',start=start,end=start+duration,level=amp))

shepard(68.5,11.0)
# A secondary choral accent is introduced late but is deliberately shorter/softer
# than the strong gathering chorus, giving a different texture without duplicating it.
add('electromagnetic choir accent',chorus_b,17.0,79.5,9.0,.25,1.5,2,.18)

# Create fair baseline and integrated comparison: preserve musical breathing, avoid
# short-window normalization or limiting; one global shared gain.
peak=max(np.max(np.abs(bed)),np.max(np.abs(out)))
rms=max(np.sqrt(np.mean(bed*bed)),np.sqrt(np.mean(out*out)))
gain=min(.88/peak,.085/rms)

for name,sig in [('starswarm-round39-A-foundation-control.mp3',bed),('starswarm-round39-B-active-sci-fi-signatures.mp3',out)]:
    target=ROOT/name
    # One constant per-file makeup gain to match integrated A/B loudness, not window compression.
    makeup=1.22 if name.endswith('active-sci-fi-signatures.mp3') else 1.0
    pcm=np.ascontiguousarray((sig*gain*makeup).T,dtype='<f4').tobytes()
    subprocess.run(['ffmpeg','-y','-loglevel','error','-f','f32le','-ar',str(SR),'-ac','2','-i','pipe:0','-c:a','libmp3lame','-b:a','128k',str(target)],input=pcm,check=True)
    print(name,target.stat().st_size,'bytes',flush=True)
print('FEATURE PLAN:',plan)
