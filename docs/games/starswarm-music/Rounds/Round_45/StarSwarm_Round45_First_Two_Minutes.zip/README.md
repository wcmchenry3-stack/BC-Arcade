# Round 45 — Signature orchestration over approved Round 44 foundation

First 120-second audition. No licensed Pixabay music, no changes to the game.

## Files
- starswarm-round45-A-round44-foundation-control.mp3 — exact first two minutes of the approved Round 44 musical foundation, re-encoded at 128 kbps
- starswarm-round45-B-signature-orchestration.mp3 — Round 44 music plus approved project-synthesized signature families
- starswarm_round45_orchestration.py — fully reproducible arrangement script
- starswarm_round18_foreground_chorus.py and starswarm_round20_spotlight_signals.py — original in-project signature generators used to regenerate signature-only stems
- starswarm-round44-seven-minute-ambient-foundation.mp3 — exact approved source bed, bundled for regeneration

## Cue timing (seconds)
- 0:10–0:27 astronomical rise
- 0:27–0:42 foundation-only gap (15 seconds)
- 0:42–1:00 varied robotic signals
- 1:00–1:16 foundation-only gap (16 seconds)
- 1:16–1:33 Gathering Swarm Chorus
- 1:33–1:49 foundation-only gap (16 seconds)
- 1:49–1:59 Electromagnetic Choir

The first 10 seconds and final second are foundation-only. Each event uses curved fades and a temporary partial backing reduction. The 'robotic signals' excerpt contains several different melodic machine gestures from the original generator rather than a single repeated pitch.

There is no descending Shepard in the first two minutes. It will be arranged independently later in the full piece to ensure it is clearly separated from rising astronomical gestures. Preserve the *audible over continuing background music* Shepard treatment approved in Round 40.

## QA and status
Both 120.048s at 24kHz stereo MP3, 128kbps, 1,921,196 bytes. A is -23.57 LUFS, -11.84 dBTP, 5.1 LU LRA. B is -24.14 LUFS, -12.27 dBTP, 4.3 LU LRA; levels are within 0.6 LU but not identical, as signature ducking deliberately creates dynamics. No clipping. No seam, finished mastering, device/SFX playback evaluation or gameplay integration claimed. The ZIP was tested with `unzip -t`.

Listen for cosmic foundation still driving continuously, character of the rise over this *new* bed, distinct robots/choruses, meaningful 15–16s breathing room, and appropriate foreground balance. A vs B is a creative comparison, not final combat-mix certification.

GitHub draft PR #3734 and audition issue #3642. The README is committed; generated MP3s and Python script are in this ZIP for owner upload (not automatically committed by the available GitHub connector).
