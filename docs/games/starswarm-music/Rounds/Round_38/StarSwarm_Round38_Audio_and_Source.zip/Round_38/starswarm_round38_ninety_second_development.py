"""Round 38: 90-second continuous melodic development from project-original sources.

Uses Round 31 generator source as synthesis primitives, and Round 36's original
scored opening. No earlier MP3, stock audio, or third-party recording imported.
Adds original third and fourth musical phrases and purposeful harmonic support
through a quiet-but-moving passage. No signature audio effects yet.
"""
from pathlib import Path
import numpy as np
from scipy.signal import butter, sosfiltfilt
import subprocess

ROOT=Path(__file__).resolve().parent
SRC=ROOT/'starswarm_round31_expressive_lead.py'
if not SRC.exists(): raise FileNotFoundError('Place Round 31 generator beside this script')
SR=24000; PACE=.87; DUR=90.; N=int(SR*DUR)
base=(ROOT/'starswarm_round36_two_phrases.py').read_text()
# Retain Round 36's exact procedural score-building rules, not its MP3.
prefix=base.split("x=ns['render']('D')",1)[0]
prefix=prefix.replace('DUR = 47.5','DUR = 90.0')
prefix=prefix.replace("code = code.replace('DUR=26.0', 'DUR=54.6')", "code = code.replace('DUR=26.0', 'DUR=104.0')")
# Extend scored harmonic path, in uncompressed original musical time.
needle='        (45.2,8.9,38,[57,62,65,69,74]),      # Dm unsettled return'
replacement=needle+'''
        # III: renewed, more urgent rising contour in E-flat/D-phrygian colors
        (53.0,5.4,39,[58,63,67,70,74]),       # Ebmaj9
        (58.1,5.3,36,[55,60,63,67,72]),       # Cm9
        (63.1,5.9,34,[53,58,62,65,70]),       # Bb
        (68.6,5.3,33,[55,61,64,69,74]),       # A sus / leading tension
        (73.6,5.3,38,[57,62,65,69,74]),       # Dm return
        # IV: subdued but ever moving, then decisive reentry
        (78.4,5.9,31,[55,58,62,65,70]),       # Gm9
        (84.0,5.4,34,[53,58,62,65,70]),       # Bb
        (89.1,5.7,36,[55,60,64,67,72]),       # C
        (94.2,5.9,33,[55,61,64,69,74]),       # A sus
        (99.7,4.0,38,[57,62,65,69,74]),       # Dm unresolved
'''
assert needle in prefix
prefix=prefix.replace(needle,replacement)
# Extend melodic line with two new arcs; distinct contour while within harmony.
end='        (50.52,77,1.12),(52.0,74,1.4),'
addition=end+'''
        # III: rising pursuit, staggered returns and a minor reversal
        (53.2,75,1.0),(54.55,77,.9),(55.67,79,1.22),(57.18,77,.75),
        (58.35,72,1.15),(59.75,75,.65),(60.55,79,1.4),(62.35,77,.85),
        (63.30,74,1.02),(64.65,77,.7),(65.58,81,1.1),(66.95,79,.93),
        (68.8,76,1.15),(70.3,74,.6),(71.05,73,1.4),(72.86,76,.8),
        (73.89,77,1.35),(75.6,74,1.05),(76.8,72,1.35),
        # IV: quieter suspended exchange, ascending after the breath
        (78.65,70,1.18),(80.04,74,.8),(81.07,77,1.36),(82.85,74,1.17),
        (84.35,72,1.04),(85.70,70,.75),(86.65,74,1.46),(88.25,77,.93),
        (89.4,79,1.25),(90.95,76,.78),(92.03,74,1.1),(93.36,72,.88),
        (94.51,73,1.25),(95.95,76,.73),(96.95,79,1.12),(98.45,77,.89),
        (100.01,74,1.32),(101.54,77,.9),(102.6,74,1.2),'''
assert end in prefix
prefix=prefix.replace(end,addition)
# Original 26s synth was sized to 104s now; keep this score deterministic.
ns={'__file__':str(ROOT/'starswarm_round36_two_phrases.py'),'__name__':'round38_builder'}
exec(compile(prefix,str(ROOT/'starswarm_round36_two_phrases.py'),'exec'),ns)
score=ns['ns']['render']('D')[:,:N].astype(np.float64)
# Round 34's purposeful spectral-balance correction, without layering more instruments.
lo=sosfiltfilt(butter(3,140,fs=SR,output='sos'),score,axis=1)
score=lo*.78+(score-lo)*1.13
# New long-form performance envelope. Varied section trajectories; real contrast
# while retaining directional harmonic movement. Quiet area still carries dynamics.
t=np.arange(N)/SR
points=[(0,.58),(.7,.76),(2.8,1.10),(5.0,1.06),(8.0,.91),
(12.0,1.16),(15.5,.82),(19.8,1.16),(22,.88),(25.0,1.12),
(30.0,.78),(34.5,1.19),(39.3,.86),(43.5,1.15),(47.0,.91),
(49.3,1.04),(53.5,1.19),(57.1,.86),(61.4,1.17),(64.8,.93),
(68.0,.86),(72.5,.76),(76.0,.87),(79.0,.95),(82.1,1.13),
(86.0,.91),(88.8,1.07),(90,.91)]
env=np.interp(t,[x[0] for x in points],[x[1] for x in points]);
window=np.hanning(3601);window/=window.sum()
env=np.convolve(np.pad(env,(1800,1800),mode='edge'),window,mode='valid')[:N]
# Put the lead further back briefly around 66-76, but keep supporting voices alive
# through the harmony's own original note sequence; never mute the whole bed.
score*=env[None,:]
score*=np.minimum(1,(DUR-t)/.18)[None,:]
# Normalized conservatively for audition; do not crush natural dynamics.
rms=np.sqrt(np.mean(score**2)); peak=np.max(abs(score));gain=min(.82/peak,.088/rms)
path=ROOT/'starswarm-round38-ninety-second-development.mp3'
cmd=['ffmpeg','-y','-loglevel','error','-f','f32le','-ar',str(SR),'-ac','2','-i','pipe:0','-c:a','libmp3lame','-b:a','128k',str(path)]
subprocess.run(cmd,input=np.ascontiguousarray((score*gain).T,dtype='<f4').tobytes(),check=True)
print(path.name,path.stat().st_size,'bytes')
