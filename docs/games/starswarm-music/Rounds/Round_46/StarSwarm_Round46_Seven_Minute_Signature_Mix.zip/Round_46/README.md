# Star Swarm — Round 46: Full Seven-Minute Signature Orchestration

**Owner listening pending.** Seven-minute **creative rough**, not mastered or certified for in-game SFX balance or seamless looping.

This continues the approved Round 44 ambient bed and the approved Round 45 first-two-minute signature arrangement. Original signature stems are freshly synthesized by earlier project-owned procedural scripts with their prior demonstration beds removed; no Pixar/Pixabay/licensed audio sampled or reused. The original Round 45 MP3 is decoded as a compositional reference for its accepted first two minutes and crossfaded back into the Round 44 bed in the last 0.7s; due to MP3 re-encoding these samples are not bit-for-bit identical, but the measured correlation during 0:00–1:59 exceeds 0.99997. The remaining five minutes consist of the uninterrupted Round 44 music and individually rendered signature events.

## Cue map (times are seconds from start)

| Window | Featured signature |
|---|---|
| 0:10–0:27 | Astronomical rise — approved Round 45 |
| 0:42–1:00 | Robotic calls — approved Round 45 |
| 1:16–1:33 | Gathering Swarm — approved Round 45 |
| 1:49–1:59 | Electromagnetic Choir — approved Round 45 |
| 2:16–2:29 | Descending Shepard — over moving bed, prominent and audible |
| 2:46–3:01 | Distant organ color — restrained, not an exposed traditional organ solo |
| 3:18–3:34 | Robotic calls — altered source segment and slightly higher register |
| 3:53–4:10 | Astronomical rise — changed arc and register |
| 4:26–4:42 | Gathering Swarm — darker register and shortened phrase |
| 5:00–5:15 | Electromagnetic Choir — changed register and phrasing |
| 5:33–5:47 | Descending Shepard — lower starting pitch and different descent rate |
| 6:04–6:19 | Robotic calls — different excerpt/contour and register |
| 6:34–6:47 | Gathering Swarm — shorter recontextualized return |
| 6:47–7:00 | Foundation alone — rough ending |

Breathing intervals are 15–19 seconds for the added events; the astronomical rises and descending Shepard tones do not overlap or immediately follow one another. Lead/melody is NOT added continuously; each signature retains its distinct identity. Exact event parameters are in `round46_cues.json` and the code.

## Files and tech QA

- `starswarm-round46-seven-minute-signature-mix.mp3`: 420.048 seconds, 24 kHz stereo, 128 kbps, 6,721,196 bytes; integrated -24.0 LUFS; LRA 6.4 LU; true peak -9.9 dBTP. No clipping.
- `starswarm_round46_full_orchestration.py`: reproducible deterministic orchestration script using numpy/scipy and ffmpeg.
- `starswarm-round44-seven-minute-ambient-foundation.mp3`: previously approved music-only source.
- `starswarm-round45-B-signature-orchestration.mp3`: approved first-two-minute reference.
- Original synthesis scripts `starswarm_round18_foreground_chorus.py`, `starswarm_round19_remaining_colors.py`, and `starswarm_round20_spotlight_signals.py` as required by generator.
- `round46_cues.json`: exact creative event sequence.

This is **not** the final mix. It hasn't been tested against laser/explosion sounds or in actual iOS/Android playback. It inherits Round 44's fade-in/fade-out, so it **does not loop seamlessly**. Loudness and codec may need revisiting. Dedicated loop, safe phrase re-entry, carry-over and rights/integration tests remain future gates. No production asset changed.

Owner audition questions: (1) Does Round 44 still feel like the foundation? (2) Are the four approved early events unchanged to your ear? (3) Are the two descending Shepard effects clear and appropriately spaced from rises? (4) Do repeats sound varied but recognizable and do the 15–19s breathing intervals feel right? (5) Any stretches too crowded or too quiet?

The ZIP contains all media and source needed to reproduce the mix. The README is committed to the existing draft PR #3734; generated binary audio still needs user upload there.
