"""Star Swarm Round 36: original connected second musical phrase.

Derives only the locally synthesized Round 31 procedural score source, not an MP3.
Both phrases use the owner-preferred Round 35B event spacing (0.87), retaining
Round 34 dynamic shape. New second phrase uses purposefully different contour,
harmonic sequence, low-register articulation and cadence. No third-party audio.
Requires: starswarm_round31_expressive_lead.py, numpy, scipy, ffmpeg.
"""
from pathlib import Path
import numpy as np
from scipy.signal import butter, sosfiltfilt
import subprocess

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT/'starswarm_round31_expressive_lead.py'
SR = 24000
PACE = .87
DUR = 47.5
N = int(SR * DUR)
code = SOURCE.read_text()
code = code.replace('DUR=26.0', 'DUR=54.6')
code = code.replace('SR=24000\n', 'SR=24000\nEVENT_PACE=1.0\n', 1)
code = code.replace('s=max(0,int(start*SR)); e=min(N,int((start+duration)*SR))',
                    'start*=EVENT_PACE; duration*=EVENT_PACE\n        s=max(0,int(start*SR)); e=min(N,int((start+duration)*SR))')
code = code.replace('s=int(st*SR); e=min(N,int((st+dur)*SR)); t=np.arange(e-s)/SR',
                    'st*=EVENT_PACE; dur*=EVENT_PACE\n        s=int(st*SR); e=min(N,int((st+dur)*SR)); t=np.arange(e-s)/SR')

old_chords = code.split('    harmony=[',1)[1].split('    for j,(start,dur,root,tones)',1)[0]
new_chords = '''
        (0,5.5,38,[57,62,65,69,74]),
        (5.1,5.6,34,[58,62,65,69,74]),
        (10.2,5.8,31,[55,58,62,67,74]),
        (15.8,5.2,33,[57,62,64,67,76]),
        (20.6,5.4,38,[57,62,65,69,74]),
        # Second idea: off-axis dark journey, before returning to tonic.
        (25.0,5.45,31,[55,58,62,65,70]),     # Gm9
        (30.1,5.2,39,[55,58,63,67,74]),      # Ebmaj7
        (35.0,5.6,34,[53,58,62,65,70]),      # Bb
        (40.3,5.25,33,[55,61,64,69,74]),     # Asus / C# leading
        (45.2,8.9,38,[57,62,65,69,74]),      # Dm unsettled return
    ]
'''
code=code.replace('    harmony=['+old_chords,'    harmony=['+new_chords)
old_notes=code.split('    notes=[',1)[1].split('    if variant==',1)[0]
new_notes = '''
        (.12,74,1.6), (1.67,76,.72),(2.44,77,1.6),(4.2,76,.65),
        (5.30,74,1.45),(6.9,72,.9),(8.02,74,1.55),(9.78,77,.9),
        (10.77,79,1.45),(12.42,77,.7),(13.24,74,1.55),
        (15.99,76,1.34),(17.87,74,.82),(18.92,79,1.22),
        (20.95,77,1.06),(22.22,76,.60),(23.05,74,1.78),
        # Different second theme: descending, then pressing upward against tension.
        (25.25,79,1.12),(26.56,77,.68),(27.39,74,1.35),(29.05,70,.95),
        (30.41,75,1.23),(31.87,74,.55),(32.57,70,1.52),(34.35,67,.83),
        (35.30,70,1.12),(36.71,74,.70),(37.58,77,1.10),(39.02,74,1.02),
        (40.60,76,.85),(41.62,74,.81),(42.58,73,1.62),(44.38,76,.72),
        (45.44,77,1.27),(46.91,74,.65),(47.80,72,1.22),(49.23,74,1.10),
        (50.52,77,1.12),(52.0,74,1.4),
    ]
'''
code=code.replace('    notes=['+old_notes,'    notes=['+new_notes)
# Expanded phrase means accents need musically assigned indices rather than a 17-value table.
code=code.replace('accent=[1.17,.86,1.08,.79,1.10,.89,1.03,.84,1.18,.83,1.12,.91,.86,1.16,.94,.79,1.14][expressive_idx]',
                  'accent=[1.17,.86,1.08,.79,1.10,.89,1.03,.84,1.18,.83,1.12,.91,.86,1.16,.94,.79,1.14][expressive_idx%17]')
# Expanded atmospheric gestures, sparse in second phrase too.
code=code.replace('(21.0,2.4,.003)]','(21.0,2.4,.003),(25.2,3.1,.003),(30.2,2.9,.0028),(35.0,3.4,.0032),(40.3,2.8,.003),(45.3,3.0,.0029)]')
code=code.replace('macro=(.55+.45*ss((time-.18)/2.15))*(.94+.06*np.sin(2*np.pi*time/9.3))',
                  'macro=(.55+.45*ss((time-.18*EVENT_PACE)/(2.15*EVENT_PACE)))*(.94+.06*np.sin(2*np.pi*time/(9.3*EVENT_PACE)))')
ns={'__name__':'round36_score','__file__':str(SOURCE)}
exec(compile(code,str(SOURCE),'exec'),ns)
ns['EVENT_PACE']=PACE
x=ns['render']('D')[:,:N].astype(np.float64)
# Mimic Round 34B register balance and direction, but continue directed dynamism
# through the new thematic response rather than looping its envelopes verbatim.
lo=sosfiltfilt(butter(3,140,fs=SR,output='sos'),x,axis=1)
x=lo*.78+(x-lo)*1.13
t=np.arange(N)/SR
knots=[(0,.58),(.5,.68),(1.6,.96),(3.3,1.14),(4.45,1.11),(5,.82),
       (5.8,1.0),(7.2,1.17),(8.85,1.10),(9.75,.82),(10.4,.92),
       (12.2,1.19),(14.2,1.06),(15.25,.78),(16.1,.93),(17.9,1.16),
       (19.0,1.08),(20.25,.76),(21.4,1.12),(22.6,.94),
       (24.1,.80),(25.5,1.08),(27.0,1.14),(28.3,.92),(29.6,.72),
       (30.8,1.09),(32.4,1.20),(34.1,.83),(35.4,1.05),(37.0,1.20),
       (38.6,.81),(40.0,1.08),(41.6,1.14),(42.6,.78),(44.1,1.09),
       (46.3,1.12),(47.5,1.04)]
# First-part envelope is compressed with musical timing; later contour is scored
# in actual seconds and connected by a smooth handoff.
pts=[(a*PACE,b) if a<=22.6 else (22.6*PACE+(a-22.6)*PACE,b) for a,b in knots]
X=np.array([q[0] for q in pts]);Y=np.array([q[1] for q in pts])
X=np.append(X,DUR);Y=np.append(Y,1.0)
env=np.interp(t,X,Y)
window=np.hanning(3601);window/=window.sum()
env=np.convolve(np.pad(env,(1800,1800),mode='edge'),window,mode='valid')[:N]
x*=env[None,:]
# Short audition-only fade, not a soundtrack loop seam.
x*=np.clip((DUR-t)/.12,0,1)[None,:]
gain=min(.82/max(np.max(abs(x)),1e-9),.105/max(np.sqrt(np.mean(x*x)),1e-9))
target=ROOT/'starswarm-round36-two-phrase-urgent-development.mp3'
cmd=['ffmpeg','-y','-loglevel','error','-f','f32le','-ar',str(SR),'-ac','2','-i','pipe:0','-c:a','libmp3lame','-b:a','128k',str(target)]
subprocess.run(cmd,input=np.ascontiguousarray((x*gain).T,dtype='<f4').tobytes(),check=True)
print(target, target.stat().st_size)
