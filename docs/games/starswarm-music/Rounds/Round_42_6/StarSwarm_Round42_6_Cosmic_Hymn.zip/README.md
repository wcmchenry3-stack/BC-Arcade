# Round 42.6 — Cosmic Hymn: Foundation-Only Sonic Palette Test

A fresh 60-second procedural musical sketch using the owner's refined specification. It is NOT another version of Round 42's chord edit, and it deliberately does NOT include any Star Swarm signature effects.

## What to listen for
- Monophonic vintage-organ/analog-synth lead: sustained, overlapping legato phrasing, expressive delayed vibrato, broad melodic line.
- Layered, continuously changing pad/drone, slowly shifting modal/classical harmonies, subtle oscillator motion within the backdrop.
- Sparse arrangement and extended digital reverb / reflected space around the lead.
- Intended emotion: cosmic, expansive, reverent, slightly melancholic *without* becoming mournful. Listen separately for whether the result retains enough underlying purpose for active gameplay.

## Arrangement
0–10s Dm(add9), 10–20s G(add9), 20–30s C6/9, 30–40s Em7, 40–50s G, 50–60s return to Dm(add9). Slow legato melodic notes change every 4–6 seconds. No percussion, no short ostinato. The harmonies and musical result are for owner judgement, not asserted as approved.

## Technical
60.048 s MP3, 24 kHz stereo at 128 kbps, integrated loudness -23.0 LUFS; LRA 3.5 LU. 1-second fade in, 2-second fade out. Not mastered, not loop-ready and not tested in gameplay. Original synthesized tones only; no sampled recordings or original BG1–4.

The included `starswarm_round42_6_cosmic_hymn.py` produces the MP3 and an intermediate 16-bit WAV with Python 3, numpy, scipy, soundfile and ffmpeg. Deterministic random seed. The intermediate WAV is intentionally excluded from the ZIP to keep it small. Run the script from any directory to generate output alongside it.

## Test gate
1. Is the warm organ-like lead emotionally expressive and genuinely legato?
2. Do the pads and long reverb feel expansive/cosmic rather than murky or generic?
3. Does the slight melancholy feel reverent instead of sorrowful?
4. Is the background musical experience independently compelling, and is there enough purpose/urgency for Star Swarm?

If the palette works but the pace is too passive, adjust the underlying musical development *within these timbres* rather than simply adding pulses, effects or dense extra voices. This sketch is deliberately only a sound design and music-phrase test; it does not replace the validated seven-minute arrangement. The approved signature effects remain out of scope until the foundation's emotional character is accepted.
