#!/usr/bin/env python3
"""Original Star Swarm foundation-only sonic palette audition; no third-party recordings.
60-second cosmic electronic-classical hymn study. Dependencies: numpy scipy soundfile ffmpeg.
"""
from pathlib import Path
import numpy as np
import soundfile as sf
from scipy.signal import fftconvolve, butter, sosfilt
import subprocess

SR=24000; DUR=60; N=SR*DUR
T=np.arange(N,dtype=np.float64)/SR
rng=np.random.default_rng(4317)
OUT=Path(__file__).resolve().parent

def hz(m): return 440*2**((m-69)/12)
def smoothstep(x):
    x=np.clip(x,0,1);return x*x*(3-2*x)
def env(t,st,en,atk=1.5,rel=2.0):
    return smoothstep((t-st)/atk)*smoothstep((en-t)/rel)*((t>=st)&(t<=en))
def hp(x,f=90):return sosfilt(butter(2,f,fs=SR,output='sos',btype='highpass'),x,axis=0)

# pad: independently moving analog-detuned oscillators, animated lowpass-ish harmonic texture
pad=np.zeros((N,2),np.float32)
chords=[
(0,11,[50,57,62,64,69]),     # Dm(add9)
(10,21,[55,62,67,69,71]),    # G(add9)
(20,31,[48,55,60,64,69]),    # C6/9
(30,41,[52,59,64,67,74]),    # Em7
(40,51,[55,62,67,71,74]),    # G major spacious
(50,60.5,[50,57,62,64,69]), # return Dm(add9), not full cadence
]
for k,(st,en,notes) in enumerate(chords):
    ix0=max(0,int((st-1)*SR)); ix1=min(N,int((en+1)*SR)); local=T[ix0:ix1]
    e=env(local,st-1,en+1,3.3,4.5)
    for j,midi in enumerate(notes):
        base=hz(midi-12 if j<2 else midi)
        # each note sounds gently different across the space
        sig=np.zeros(len(local))
        for det in (-.0031,.0026):
            phase=2*np.pi*base*(1+det)*local+(k+j*0.61)
            sig+=.49*np.sin(phase)+.14*np.sin(2*phase+0.4)+.042*np.sin(3*phase+1.1)
        drift=.82+.18*np.sin(2*np.pi*(.071+.004*j)*local+.5*j+1.1*k)
        sig*=e*drift*(.84 if j<2 else .55)
        pan=.20+.6*((j*0.37+k*.13)%1)
        pad[ix0:ix1,0]+=sig*(1-pan)
        pad[ix0:ix1,1]+=sig*pan

# continuous evolving low drone: retains harmonic movement and low pulse w/o drums
bass=np.zeros(N,dtype=np.float32)
for st,en,notes in chords:
    root=hz(notes[0]-12)
    e=env(T,st-1,en+1,3.5,4.0)
    low=np.sin(2*np.pi*root*T+.15*np.sin(2*np.pi*.19*T))
    low+=.18*np.sin(2*np.pi*2*root*T)
    moving=.77+.23*np.sin(2*np.pi*.24*T+0.3)
    bass+= (.14*low*e*moving).astype(np.float32)

# a single vintage monophonic analog-organ lead; warm harmonics, nonlinear vibrato that grows into each held note
lead=np.zeros(N,np.float32)
# Each note connects with next: lower-level overlapping transitions and expressive phrase breathing.
melody=[
(2.0,7.2,69),(7.0,12.1,71),(11.9,16.3,74),(16.0,20.3,76),
(21.0,26.1,74),(25.8,30.8,71),(30.5,35.2,69),(35.0,39.5,71),
(40.0,45.6,74),(45.3,50.0,76),(50.1,55.3,74),(55.0,60.0,69)]
for idx,(st,en,m) in enumerate(melody):
    a=max(0,int((st-.2)*SR));b=min(N,int((en+.2)*SR));tt=T[a:b]
    elapsed=np.maximum(tt-st,0)
    vibrato_depth=.0035*smoothstep((elapsed-.6)/1.7)
    vibrato_rate=4.7+.3*np.sin(.24*idx)
    # integral of pitch modulation to a smooth, delayed vibrato
    mod=(vibrato_depth/vibrato_rate)*np.cos(2*np.pi*vibrato_rate*elapsed+.8*idx)
    ph=2*np.pi*hz(m)*(tt+mod)
    # crossfade phrase ends so notes connect, no abrupt MIDI-gate feel
    attack=smoothstep((tt-st)/.65);release=smoothstep((en-tt)/.9)
    phrase=(.86+.14*np.sin(2*np.pi*.26*tt+.2*idx))*attack*release
    # vintage monophonic organ-adjacent tone, lower partials dominate
    sound=(.64*np.sin(ph)+.29*np.sin(2*ph+.12)+.115*np.sin(3*ph+.4)+.042*np.sin(4*ph+.7))
    lead[a:b]+= (sound*phrase*.26).astype(np.float32)

# stereo evolving electronic sweeps are embedded in the ambient texture, not standalone signature effects
sweep=np.zeros((N,2),np.float32)
for idx,(st,en,notes) in enumerate(chords):
    a=int(st*SR);b=min(N,int(en*SR));tt=T[a:b];dt=tt-st
    root=hz(notes[1]);f=root*(1+.32*smoothstep(dt/(en-st)))
    phi=2*np.pi*root*(dt+(.32/(en-st))*.5*dt*dt)
    sw=np.sin(phi)*env(tt,st,en,3,3)*.033
    sweep[a:b,0]+=sw*(.66 if idx%2 else .33)
    sweep[a:b,1]+=sw*(.33 if idx%2 else .66)

# Low-mid cleanup and stereo placement; reverb with sparse early reflections and long diffuse tail.
pad=hp(pad,115)
dry=np.stack((.60*pad[:,0]+.80*lead+.60*bass+.7*sweep[:,0],
              .60*pad[:,1]+.80*lead+.60*bass+.7*sweep[:,1]),axis=1).astype(np.float32)
wet=np.zeros_like(dry)
for channel in range(2):
    seconds=4.7; irN=int(SR*seconds)
    ir=np.zeros(irN,dtype=np.float32)
    # controlled series of non-repeating delays plus decaying diffuse shimmer
    early=[(.067,.16),(.117,.13),(.183,.11),(.271,.085),(.393,.065),(.587,.05)]
    for delay,gain in early:ir[min(irN-1,int((delay+.013*channel)*SR))]+=gain
    noise=rng.normal(0,1,irN)
    noise=sosfilt(butter(1,5000,fs=SR,output='sos'),noise)
    tail=np.exp(-np.arange(irN)/SR/1.18)*noise
    tail[:int(.08*SR)]*=np.linspace(0,1,int(.08*SR))
    ir+=.0022*tail.astype(np.float32)
    wet[:,channel]=fftconvolve(dry[:,1-channel],ir,mode='full')[:N].astype(np.float32)

mix=.79*dry+.64*wet
# remove subsonic buildup, controlled fades. deliberately not a loop-ready master.
mix=hp(mix,35)
mix[:SR]*=np.linspace(0,1,SR)[:,None]
mix[-2*SR:]*=np.linspace(1,0,2*SR)[:,None]
peak=np.max(np.abs(mix));mix=(mix/peak*.33).astype(np.float32)
wav=OUT/'starswarm-round42_6-cosmic-hymn-foundation.wav'
mp3=OUT/'starswarm-round42_6-cosmic-hymn-foundation.mp3'
sf.write(wav,mix,SR,subtype='PCM_16')
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(wav),'-codec:a','libmp3lame','-b:a','128k',str(mp3)],check=True)
print(f'Created {mp3}, peak {peak:.4f}, duration {DUR}s')
