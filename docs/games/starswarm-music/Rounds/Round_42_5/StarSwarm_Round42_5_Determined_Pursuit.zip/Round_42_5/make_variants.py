from pathlib import Path
p=Path(__file__).parent
src=(p/'original_round42_foundation.py').read_text()
src=src.replace('DUR=420','DUR=60').replace('for section in range(7):','for section in range(1):')
src=src.replace("filename=ROOT/'starswarm-round42-seven-minute-foundation-rough.mp3'","filename=ROOT/'starswarm-round42_5-A-mournful-control.mp3'")
(p/'_A_render.py').write_text(src)
modified=src.replace("filename=ROOT/'starswarm-round42_5-A-mournful-control.mp3'","filename=ROOT/'starswarm-round42_5-B-determined-pursuit.mp3'")
# replace only section 0 chord progression using newly voiced triad/suspension colors; preserve 11 phrase boundaries.
modified=modified.replace("'Csus':(36,[55,60,65,67,74]),'Am':(33,[57,60,64,69,72]),'Bbadd':(34,[58,62,65,70,77]),", "'Csus':(36,[55,60,65,67,74]),'Am':(33,[57,60,64,69,72]),'Bbadd':(34,[58,62,65,70,77]),\n'Dm9':(38,[57,62,64,69,74]),'Gmaj':(31,[55,59,62,67,74]),'Cadd9':(36,[55,60,62,67,72]),'Asus':(33,[57,62,64,69,74]),")
modified=modified.replace("['Dm','Bb','Gm','A7sus','Dm','Gm','Bb','A7sus','Dm','F','Gm'],", "['Dm9','Gmaj','Cadd9','Asus','Dm9','Gmaj','Cadd9','Asus','Dm9','Gmaj','Asus'],")
modified=modified.replace("([0,2,3,2,0,-2,0,3,4,2,0,-2,-3,-1,0],", "([0,2,4,3,1,0,2,4,5,3,2,1,0,2,4],")
modified=modified.replace("0:[70,72,74,76,77,79,81,82,84]", "0:[69,71,72,74,76,79,81,83,86]")
# Original score-level movement maintained; leave instrument, dynamics and synthesis identical.
(p/'_B_render.py').write_text(modified)
print('Generated from original procedural source; musical form 60s, section 0, changes only harmony & phrase contour.')
