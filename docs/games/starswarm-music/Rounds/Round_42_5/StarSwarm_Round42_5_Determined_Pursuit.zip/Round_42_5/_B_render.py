"""Round 42: original, foundation-only 7-minute developmental rough.

No licensed audio or older rendered audio read. All notes and timbres generated from
code; an original score in seven linked movements, not repeated MP3 segments.
Requirements: numpy, scipy, ffmpeg. Fixed parameters + deterministic randomness.
"""
from pathlib import Path
import numpy as np
from scipy.signal import butter, sosfilt, sosfiltfilt
import subprocess

ROOT=Path(__file__).resolve().parent
SR=24000
DUR=60
N=SR*DUR
RNG=np.random.default_rng(4242)
sound=np.zeros((2,N),np.float32)

def smooth(x):
    x=np.clip(x,0,1)
    return x*x*(3-2*x)
def hz(n):return 440.*2**((n-69)/12)

def voice(midi, start, length, gain, role, pan, idx, attack=.09, release=.35, gesture=0):
    a=max(0,int(start*SR));b=min(N,int((start+length)*SR))
    if b<=a:return
    t=np.arange(b-a,dtype=np.float32)/SR
    # Purposeful pitch approach/settling and slowly evolving electronic partials.
    approach=(2.7 if idx%4 else -6.2)*np.exp(-t/.094)
    bend=(1.8 if idx%3 else -1.4)*smooth((t-.26)/.5)
    cents=approach+bend+1.05*np.sin(2*np.pi*.38*t+idx*.27)*smooth((t-.16)/.42)
    ph=2*np.pi*np.cumsum((hz(midi)*2**(cents/1200.)/SR).astype(np.float64))+idx*.31
    evolution=smooth((t-.13)/max(.25,length*.40))*smooth((length-t)/max(.2,length*.25))
    if role=='lead':
        mod=(.23+.12*evolution)*np.sin(.75*ph+.22*np.sin(2*np.pi*.28*t))
        x=.86*np.sin(ph+mod)+(.13+.11*evolution)*np.sin(2*ph+.18)+(.025+.038*evolution)*np.sin(2.51*ph+.48)
    elif role=='field':
        x=.82*np.sin(ph)+(.23+.08*evolution)*np.sin(2*ph+.3)+.068*np.sin(3.04*ph+.48)
    elif role=='coil':
        x=.81*np.sin(ph)+.20*np.sin(2.01*ph+.11)+(.04+.06*evolution)*np.sin(3.02*ph+.7)
    elif role=='sub':
        x=np.sin(ph)+.22*np.sin(2*ph+.17)+.09*np.sin(3*ph+.42)
    elif role=='aether':
        x=.72*np.sin(ph)+.13*np.sin(1.51*ph+.4)+.11*np.sin(2.39*ph+.15)
    else:raise ValueError(role)
    env=smooth(t/max(.015,attack))*smooth((length-t)/max(.08,release))
    if role in ('lead','coil','field'):
        env*=.78+.22*smooth((t-.13)/max(.3,length*.51))
        env*=.94+.06*np.sin(2*np.pi*(.42+.012*(idx%8))*t+.2)**2
    if role=='lead':
        # accents reflect phrase position, not random timing scatter
        env*=1.13 if gesture==1 else (.83 if gesture==-1 else 1)
    y=(gain*x*env).astype(np.float32)
    ang=(pan+1)*np.pi/4
    sound[0,a:b]+=np.cos(ang)*y
    sound[1,a:b]+=np.sin(ang)*y

# Connected diatonic and suspended colors; all phrases original.
CH={
'Dm':(38,[57,62,65,69,74]),'Bb':(34,[58,62,65,69,74]),'Gm':(31,[55,58,62,67,74]),
'A7sus':(33,[55,61,64,69,74]),'Eb':(39,[58,63,67,70,74]),
'Cm':(36,[55,60,63,67,72]),'F':(41,[57,60,65,69,72]),
'Csus':(36,[55,60,65,67,74]),'Am':(33,[57,60,64,69,72]),'Bbadd':(34,[58,62,65,70,77]),
'Dm9':(38,[57,62,64,69,74]),'Gmaj':(31,[55,59,62,67,74]),'Cadd9':(36,[55,60,62,67,72]),'Asus':(33,[57,62,64,69,74]),
}
# Every 60-s chapter changes harmonic grammar. Slightly varying phrase lengths and durations
# keep variation musically legible without random chord hopping.
PROGS=[
 ['Dm9','Gmaj','Cadd9','Asus','Dm9','Gmaj','Cadd9','Asus','Dm9','Gmaj','Asus'],
 ['Gm','Eb','Bb','A7sus','Dm','Cm','Gm','A7sus','Bb','Gm','Dm'],
 ['Dm','F','Bbadd','Gm','Eb','Cm','A7sus','Dm','Gm','A7sus','Dm'],
 ['Gm','Cm','Eb','Bb','Gm','Csus','A7sus','Dm','F','Gm','A7sus'],
 ['Dm','Bb','F','Eb','Cm','Gm','A7sus','Dm','Bbadd','Am','A7sus'],
 ['Gm','Eb','Cm','Bb','F','Gm','A7sus','Dm','Csus','Am','Bb'],
 ['Dm','Bb','Gm','F','Eb','Bbadd','A7sus','Gm','Dm','A7sus','Dm'],
]
# Themes have different *pitch contour, rhythmic fingerprint and emotional job*.
# The note ordering is material written for this piece; repeat appearances are transformed.
MOTIFS=[
  ([0,2,4,3,1,0,2,4,5,3,2,1,0,2,4], [1.15,.58,1.36,.67,1.07,.76,1.41,.73,1.24,.66,1.1,.80,1.44,.73,1.19]),
  ([4,3,0,-3,-1,0,3,1,0,-2,0,2,1,-1,-3], [1.2,.71,1.58,.87,1.03,.64,1.32,.89,1.25,.71,1.03,.83,1.42,.73,1.35]),
  ([0,1,4,2,3,0,-1,2,5,3,1,0,3,1,-2], [.82,.74,1.62,.62,.85,1.27,.73,1.36,.62,1.21,.91,.71,1.39,.74,1.45]),
]
SCALES={
 0:[69,71,72,74,76,79,81,83,86],
 1:[67,70,72,74,75,77,79,82,84],
 2:[69,72,74,75,77,79,81,82,84],
}
# Compose a long evolving music bed with transitions between overlapping harmonies.
# Pacing near owner-favored 35B (about 13% tighter than earlier phrase timing).
section_modes=[0,1,2,1,0,2,0]
section_emphasis=[1.05,1.12,.80,1.10,1.12,.82,1.14]
idx=0
for section in range(1):
    print("Synthesizing section",section+1,"/7",flush=True)
    base=section*60.0
    progression=PROGS[section]
    chord_starts=np.linspace(0,60,len(progression)+1)[:-1]
    chord_starts+=np.array([0,.12,-.09,.18,-.06,.07,-.14,.11,-.07,.08,-.04])[:len(progression)]
    for j,name in enumerate(progression):
        st=base+float(chord_starts[j]); nxt=base+(float(chord_starts[j+1]) if j+1<len(progression) else 60)
        dur=max(3.0,nxt-st)
        root,tones=CH[name]
        # Segment-dependent voicings: common-tone voice leading; not identical chord stack.
        section_tones=[tones[k] + (12 if ((section+j+k)%11==0 and k>=3) else 0) for k in range(5)]
        voice(root,st,dur+.45,.036*section_emphasis[section],'sub',-.12,j+section*30,attack=.17,release=.65)
        for k,p in enumerate(section_tones[:4]):
            if k==4 and (section+j)%4==1:continue # opening space for lead
            off=[0,.12,.26,.43,.58][k]
            voice(p,st+off,max(.45,dur-off+.20),(.0092 if k<3 else .0062)*section_emphasis[section],
                  'field' if k%2==0 else 'coil',pan=-.60+.27*k,idx=100+section*70+j*5+k,
                  attack=.27 if k>=3 else .18,release=.65)
        # The low figure is distinctive per movement: never same repeating pattern everywhere.
        movements=[(1.0,7,.68),(2.15,12,.65),(3.3,7,.71),(4.45,10,.50)] if section%2==0 else [(1.35,12,.71),(2.48,7,.55),(3.80,10,.67)]
        for k,(off,iv,ln) in enumerate(movements[:2]):
            if off < dur-.2:
                voice(root+iv,st+off,ln,.011*(1 if section not in (2,5) else .81),'coil',
                      .25 if k%2 else -.31,200+section*40+j*4+k,attack=.06,release=.17)
    # Upper line with 3 interrelated motifs, varied starting pitch/register/phrase omissions.
    motif_id=section_modes[section]
    contour,durations=MOTIFS[motif_id]
    scale=SCALES[motif_id]
    phrase_start=base+.32
    phrase_len=25.6 if section%3!=1 else 27.4
    for phrase in range(2):
        start=phrase_start+phrase*29.4
        total=0.
        for k in range(15):
            variation=(k+section*3+phrase*2)%15
            if section in (2,5) and k in (3,10):
                total+=1.1 # airier quiet passages still have supporting motion
                continue
            interval=contour[variation]
            # A clear melodic arc, grounded in mode, with gradual thematic transformation.
            center=4+int(round(.4*np.sin(section*1.8+phrase)))
            pitch=scale[int(np.clip(center+interval,0,len(scale)-1))]
            length=durations[variation]*(1.07 if section in (2,5) else 1.0)
            off=start+total
            if off>=base+59.5:break
            voice(pitch,off,length+.12,.0178*section_emphasis[section], 'lead',
                  pan=.24 if (k+phrase)%2 else -.26,idx=500+section*80+phrase*20+k,
                  attack=.10,release=.33,gesture=(1 if k in (0,3,8,14) else -1 if k in (5,11) else 0))
            # Cadential answer is occasional, not another constant competing melody.
            if k in (4,12) and section in (1,3,4,6):
                voice(pitch-12,off+.25,min(1.2,length+.12),.0037,'aether',
                      -.43 if k%2 else .45,idx=800+section*20+k,attack=.23,release=.35)
            total+=length+(.33 if k%3==0 else .21)
    # Deterministic, extremely restrained internal atmospheres—not approved signatures.
    for j in range(3):
        at=base+8.5+j*17.8+(section%3)*.5
        length=3.1+j*.3
        a=int(at*SR);b=min(N,int((at+length)*SR))
        if b<=a:continue
        w=RNG.normal(0,1,b-a).astype(np.float32)
        sos=butter(2,[600+130*j,1900+180*j],btype='bandpass',fs=SR,output='sos')
        w=sosfilt(sos,w).astype(np.float32);w/=np.std(w)+1e-6
        tt=np.arange(b-a,dtype=np.float32)/SR
        env=smooth(tt/(length*.48))*smooth((length-tt)/(length*.4))
        sound[j%2,a:b]+=.0017*w*env

# Modest spectral rebalance and score-level dynamic movement (not a loudness squasher).
lo=sosfilt(butter(2,140,fs=SR,output='sos'),sound,axis=1)
sound=(lo*.80+(sound-lo)*1.13).astype(np.float32)
t=np.arange(N,dtype=np.float32)/SR
# Unique macro-arc per minute, continuous at boundaries. Last section returns toward opening.
knots=[(0,.61),(2.8,1.05),(11,1.12),(19,.86),(32,1.13),(48,.91),(60,1.05),
(75,1.18),(89,.84),(101,1.15),(120,.99), (139,.75),(154,.87),(168,1.06),(180,.89),
(196,1.12),(212,.84),(232,1.18),(240,.99),(254,1.18),(272,.90),(289,1.07),(300,.95),
(315,.75),(331,.90),(348,1.06),(360,1.02),(379,1.15),(397,.83),(407,1.09),(419,.92),(420,.91)]
env=np.interp(t,[a for a,b in knots],[b for a,b in knots]).astype(np.float32)
# Use smoothing only on the broad scored dynamic envelope, not on audio short-term LUFS.
from scipy.ndimage import gaussian_filter1d
# Envelope is already smooth through the scored knot interpolation
sound*=env[None,:]
# A short natural end fade only for first creative rough; loop seam deliberately NOT certified.
sound*=smooth((DUR-t)/.36)[None,:]
# Sparse early reflections, not a blurry wash.
dry=sound.copy()
for ch in range(2):
    for seconds,gain in [(0.13,.064),(.41,.049),(.87,.025)]:
        delay=int((seconds+ch*.037)*SR)
        sound[ch,delay:]+=gain*dry[1-ch,:-delay]
peak=float(np.max(np.abs(sound)))
rms=float(np.sqrt(np.mean(sound.astype(np.float64)**2)))
gain=min(.84/peak,.070/max(rms,1e-6))
print('unmastered RMS',rms,'peak',peak,'gain',gain,flush=True)
filename=ROOT/'starswarm-round42_5-B-determined-pursuit.mp3'
cmd=['ffmpeg','-y','-loglevel','error','-f','f32le','-ac','2','-ar',str(SR),'-i','pipe:0',
     '-c:a','libmp3lame','-b:a','112k',str(filename)]
subprocess.run(cmd,input=np.ascontiguousarray((sound*gain).T,dtype='<f4').tobytes(),check=True)
print(filename,filename.stat().st_size)
