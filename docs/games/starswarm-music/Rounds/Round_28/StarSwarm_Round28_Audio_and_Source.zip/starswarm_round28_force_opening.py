"""Star Swarm Round 28: original 22-second coordinated-force cinematic intro.

Built from synthesized voices and noise only. No reference audio is read, copied,
transcribed or used during synthesis. Requires numpy, scipy, ffmpeg.
"""
from pathlib import Path
import subprocess
import numpy as np
from scipy.signal import butter, sosfilt

SR=24000
DUR=22.0
N=int(SR*DUR)
OUT=Path(__file__).resolve().parent
rng=np.random.default_rng(2804)
score=np.zeros((2,N),dtype=np.float32)

def hz(n):return 440*2**((n-69)/12)
def ss(z):
 z=np.clip(z,0.,1.)
 return z*z*(3-2*z)

def voice(midi,start,duration,volume,kind='field',pan=0.,attack=.12,release=.42,seed=0,drift=0):
 s=max(0,int(start*SR)); e=min(N,int((start+duration)*SR));
 if e<=s:return
 t=np.arange(e-s,dtype=np.float64)/SR
 # An electronically modulated tone, not a sampled string/brass/choir instrument.
 cents=2.5*np.sin(2*np.pi*(.28+seed*.008)*t+seed)+1.7*np.sin(2*np.pi*.84*t+seed*.2)
 ph=2*np.pi*np.cumsum(hz(midi)*2**(cents/1200)/SR)+seed*.3
 if kind=='field':
  x=(.78*np.sin(ph)+.31*np.sin(2*ph+.21)+.17*np.sin(3.013*ph+.7)+.12*np.sin(4.17*ph+.32))
 elif kind=='coil':
  x=(.78*np.sin(ph)+.27*np.sin(2.015*ph)+.17*np.sin(2.97*ph+.35)+.11*np.sin(5.28*ph))
 elif kind=='sub':
  x=np.sin(ph)+.28*np.sin(2*ph+.3)+.14*np.sin(3*ph+.6)
 elif kind=='aether':
  x=.67*np.sin(ph)+.19*np.sin(1.5*ph+.1)+.14*np.sin(2.41*ph+.4)
 else:raise ValueError(kind)
 env=ss(t/max(.02,attack))*ss((duration-t)/max(.06,release))
 if kind in ('field','coil'):
  env*=.80+.20*np.sin(2*np.pi*(.35+seed*.011)*t+.3)**2
 # Controlled directional gain ramp, each voice moves as part of one musical statement.
 env*=1+drift*(t/max(duration,.001)-.5)
 y=(volume*x*env).astype(np.float32)
 ang=np.pi*(pan+1)/4
 score[0,s:e]+=np.cos(ang)*y
 score[1,s:e]+=np.sin(ang)*y

# Orchestrated harmony: Dm(add9) -> Bbmaj7(#11) -> Gm9 -> A(sus4,b9).
# Long shared upper pitches and bass contrary motion make the lift feel like one event.
harmony=[
 (0,5.5,38,[57,62,65,69,76]),
 (5.1,5.6,34,[57,62,65,70,76]),
 (10.2,5.8,31,[55,58,62,65,74]),
 (15.8,6.2,33,[55,57,62,64,70]),
]
for j,(start,dur,root,tones) in enumerate(harmony):
 # Low foundation and articulated, not-metronomic forward steps.
 voice(root,start,dur+.18,.047,'sub',-.15,attack=.10 if j else .18,release=.52,seed=10+j)
 for k,p in enumerate(tones):
  # Coordinated entries grow a sustained ensemble with broad registers.
  entry=start+[.00,.14,.27,.51,.72][k]
  voice(p,entry,max(.1,dur-[.00,.14,.27,.51,.72][k]),.0147 if k<3 else .0112,
        'field' if k%2==0 else 'coil',pan=-.65+.3*k,
        attack=.16 if k<3 else .38,release=.72,seed=21+j*9+k,drift=.12)
 # Bass steps respond to the chord; rhythm is embedded in the harmony, not an added beat loop.
 for k,(off,iv) in enumerate([(1.24,7),(2.38,12),(3.48,7),(4.31,10)]):
  if off<dur-.35:voice(root+iv,start+off,.75,.018,'coil',pan=.35 if k%2 else -.3,
                         attack=.045,release=.24,seed=80+j*5+k)

# An original shared ascent: starts almost immediately, but is answered/revoiced, not endlessly repeated.
# Related notes are passed across the field (not exposed orchestral horns).
notes=[(.12,74,1.6), (1.67,76,.72),(2.44,77,1.6),(4.2,76,.65),
       (5.30,74,1.45),(6.9,72,.9),(8.02,74,1.55),(9.78,77,.9),
       (10.77,79,1.45),(12.42,77,.7),(13.24,74,1.55),
       (15.99,76,1.6),(17.87,74,.94),(18.92,77,1.7)]
for i,(st,p,d) in enumerate(notes):
 voice(p,st,d,.025 if i%3 else .030,'coil' if i%2 else 'field',
       pan=.40 if i%2 else -.42,attack=.065,release=.25,seed=120+i)
 # Late octave shadows connect the lead into the lower musical mass.
 if i in [2,6,10,13]:voice(p-12,st+.22,min(1.6,d+.20),.010,'aether',
                      pan=.5 if i%2 else -.5,attack=.18,release=.35,seed=210+i)

# Rising spectral current is integrated into the main chord arrival, NOT an approved astro-rise effect.
# Coherent narrowband filtered wash, short bursts only: no generic ocean/surf loop.
for k,(st,dur,amp) in enumerate([(.15,3.2,.0035),(5.25,2.4,.003),(10.1,2.7,.0038),(15.9,3.6,.003)]):
 s=int(st*SR);e=min(N,int((st+dur)*SR));t=np.arange(e-s)/SR
 white=rng.normal(0,1,len(t))
 sos=butter(3,[650+130*k,2100+140*k],fs=SR,btype='bandpass',output='sos')
 band=sosfilt(sos,white)
 band=band/(np.std(band)+1e-8)
 env=ss(t/(dur*.48))*ss((dur-t)/(dur*.39))
 for ch in range(2):score[ch,s:e]+=amp*band*env*(.85 if ch==k%2 else .6)

# The initial ~3 sec rises in power; it never simply hits at max and falls away.
time=np.arange(N)/SR
macro=(.55+.45*ss((time-.18)/2.15))*(.94+.06*np.sin(2*np.pi*time/9.3))
macro*=ss((DUR-time)/.30)
score*=macro[None,:]
# Spatial reflections from synths only, leaving dry attacks defined.
dry=score.copy()
for ch in range(2):
 for delay,gain in [(0.11,.11),(0.39,.073),(0.81,.038)]:
  lag=int((delay+.035*ch)*SR)
  score[ch,lag:]+=gain*dry[1-ch,:-lag]
peak=np.max(np.abs(score))
score*=.83/max(peak,.0001)
path=OUT/'starswarm-round28-coordinated-force-opening.mp3'
cmd=['ffmpeg','-y','-loglevel','error','-f','f32le','-ar',str(SR),'-ac','2','-i','pipe:0',
     '-c:a','libmp3lame','-b:a','128k',str(path)]
subprocess.run(cmd,input=np.ascontiguousarray(score.T,dtype='<f4').tobytes(),check=True)
print(path.name, path.stat().st_size, 'bytes')
