"""Round 35: force-preserving, darker/faster musical motion test.

A and B are independently synthesized from the original Round 31 score with the
same orchestration and notes. A retains Round 34B timing; B schedules those same
note events 13% closer in time without time-stretching audio or changing pitch.
Both retain Round 34B's register balance and the same dynamic contour.
No original third-party audio or pre-rendered MP3 is imported.
"""
from pathlib import Path
import importlib.util
import subprocess
import numpy as np
from scipy.signal import butter, sosfiltfilt

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'starswarm_round31_expressive_lead.py'
SR=24000
DUR=22.0
N=int(DUR*SR)

# Use the exact original procedural source. Alter only EVENT schedule in variant B.
code=SOURCE.read_text()
code=code.replace("s=max(0,int(start*SR)); e=min(N,int((start+duration)*SR))", "start*=EVENT_PACE; duration*=EVENT_PACE\n        s=max(0,int(start*SR)); e=min(N,int((start+duration)*SR))")
code=code.replace("SR=24000\n", "SR=24000\nEVENT_PACE=1.0\n",1)
# The atmospheric gestures are also rescheduled (not layered more densely).
code=code.replace("s=int(st*SR); e=min(N,int((st+dur)*SR)); t=np.arange(e-s)/SR", "st*=EVENT_PACE;dur*=EVENT_PACE\n        s=int(st*SR); e=min(N,int((st+dur)*SR)); t=np.arange(e-s)/SR")
# Preserve the dynamic build character relative to musical time in each version.
code=code.replace("macro=(.55+.45*ss((time-.18)/2.15))*(.94+.06*np.sin(2*np.pi*time/9.3))", "macro=(.55+.45*ss((time-.18*EVENT_PACE)/(2.15*EVENT_PACE)))*(.94+.06*np.sin(2*np.pi*time/(9.3*EVENT_PACE)))")
ns={'__name__':'round35_synthesis','__file__':str(SOURCE)}
exec(compile(code,str(SOURCE),'exec'),ns)

def generate(pace):
    ns['EVENT_PACE']=pace
    x=ns['render']('D')[:,:N].astype(np.float64)
    # Consistent Round 34B musical force: spectral balance & directed energy.
    low=sosfiltfilt(butter(3,140,fs=SR,output='sos'),x,axis=1)
    x=low*.78+(x-low)*1.13
    t=np.arange(N)/SR
    knots=[(0,.58),(.5,.68),(1.6,.96),(3.3,1.14),(4.45,1.11),(5.0,.82),
           (5.8,1.00),(7.2,1.17),(8.85,1.10),(9.75,.82),(10.4,.92),
           (12.2,1.19),(14.2,1.06),(15.25,.78),(16.1,.93),(17.9,1.16),
           (19.0,1.08),(20.25,.76),(21.4,1.12),(22,.98)]
    # B's envelopes follow the faster harmonic phrase boundaries, not a new beat.
    xp=np.array([v[0]*pace for v in knots]); yp=np.array([v[1] for v in knots])
    # Continue last arch through the new 22s window; don't end in a sudden cutoff.
    if xp[-1]<DUR:
        xp=np.append(xp,DUR);yp=np.append(yp,1.02)
    env=np.interp(t,xp,yp)
    k=int(.15*SR);k+=1-k%2
    win=np.hanning(k);win/=win.sum()
    env=np.convolve(np.pad(env,(k//2,k//2),mode='edge'),win,mode='valid')[:N]
    x*=env[None,:]
    # Tiny 100ms end fade purely for audition excerpts; final music not fade out here.
    x*=np.clip((DUR-t)/.10,0,1)[None,:]
    return x

A=generate(1.0)
B=generate(.87)
# Match overall energy fairly; common limiting peak allowance.
energy=lambda x:np.sqrt(np.mean(x*x))
B*=energy(A)/max(energy(B),1e-12)
scale=min(.90/max(np.max(abs(A)),np.max(abs(B))),.11/max(energy(A),energy(B)))
for name,x in [
    ('starswarm-round35-A-directed-force-control.mp3',A),
    ('starswarm-round35-B-dark-forward-motion.mp3',B),
]:
    out=ROOT/name
    pcm=np.ascontiguousarray((x*scale).T,dtype='<f4').tobytes()
    cmd=['ffmpeg','-y','-loglevel','error','-f','f32le','-ar',str(SR),'-ac','2','-i','pipe:0','-c:a','libmp3lame','-b:a','128k',str(out)]
    subprocess.run(cmd,input=pcm,check=True)
    print(out.name,out.stat().st_size,'bytes')
