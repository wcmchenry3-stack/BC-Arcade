#!/usr/bin/env python3
"""Star Swarm Round 42.7: independent foundation-only cosmic motion test.
Original procedural synthesis; no sample recordings; no signature effects.
Requires numpy scipy soundfile and ffmpeg.
"""
from pathlib import Path
import numpy as np, soundfile as sf, subprocess
from scipy.signal import fftconvolve, butter, sosfilt
SR=24000; DUR=60.; N=int(SR*DUR); rng=np.random.default_rng(4277)
T=np.arange(N)/SR; OUT=Path(__file__).resolve().parent

def hz(n): return 440*2**((n-69)/12)
def sm(x):
 x=np.clip(x,0,1); return x*x*(3-2*x)
def fade(t,a,b,attack=2.5,release=3.5):return sm((t-a)/attack)*sm((b-t)/release)*((t>=a)&(t<=b))
def filterhp(x,h): return sosfilt(butter(2,h,fs=SR,output='sos',btype='highpass'),x,axis=0)

# E pedal / open fifth continuity; large suspended planing shapes without strong cadences.
# Three or four soft pitch voices per pane, *not* dense choral polyphony.
scenes=[(0,17,[40,47,57,62]),(13,31,[40,47,59,64]),(27,45,[40,47,57,66]),(41,61,[40,47,59,62])]
pad=np.zeros((N,2),np.float32)
for k,(a,b,notes) in enumerate(scenes):
 l=max(0,int((a-3)*SR));r=min(N,int((b+3)*SR));tt=T[l:r]
 e=fade(tt,a-3,b+3,5.8,6.5)
 for j,m in enumerate(notes):
  base=hz(m); p1=2*np.pi*base*(tt+(.003*np.sin(2*np.pi*(.025+.003*j)*tt+k*.6)))
  p2=2*np.pi*base*1.0037*tt + .6*k+1.1*j
  # Sine-ish electronic core with evolving, frequency-breathing high harmonics.
  s=(.53*np.sin(p1)+.33*np.sin(p2)+(.045+.036*np.sin(.21*tt+j))*np.sin(2*p1+.8)+.022*np.sin(3*p2))
  scan=.77+.23*np.sin(2*np.pi*(.043+.006*j)*tt + k*.95+j*.8)
  amp=e*scan*(.65 if j<2 else .42)
  # Time-changing stereo field with stable center of gravity.
  pan=np.clip(.5 + .26*np.sin(2*np.pi*.011*tt + j*2.1 + k),.15,.85)
  pad[l:r,0]+= (s*amp*(1-pan)).astype(np.float32)
  pad[l:r,1]+= (s*amp*pan).astype(np.float32)

# E harmonic current: continuous, evolving, undulating but no regular driving beat.
dr=np.sin(2*np.pi*hz(28)*T + .7*np.sin(2*np.pi*.037*T))
dr+=.26*np.sin(2*np.pi*hz(40)*T+.21*np.sin(2*np.pi*.11*T))
dr*= .07*(.79+.21*np.sin(2*np.pi*.067*T+.8))

# Mono expressive *electronic* lead, sparse few notes, lightly FM/oscillator color instead of bowed tone.
# 5-8 second notes with phrase space, no dense harmonized lines.
mel=[(3.0,10.8,71),(11.4,18.3,74),(19.0,25.9,76),(27.0,34.1,74),
     (35.5,42.8,71),(44.0,50.7,73),(51.4,59.1,74)]
lead=np.zeros(N,np.float32)
for j,(a,b,m) in enumerate(mel):
 l=int(a*SR);r=min(N,int(b*SR));tt=T[l:r]; dt=tt-a
 depth=.0029*sm((dt-.7)/2.2)
 # Integrate delayed vibrato frequency modulation into the phase.
 vib=(depth/(2*np.pi*4.8))*np.sin(2*np.pi*4.8*dt + j*.38)
 phase=2*np.pi*hz(m)*(dt+vib)
 expression=(.73+.27*np.sin(np.pi*np.clip(dt/(b-a),0,1)))*fade(tt,a,b,1.5,1.7)
 timbre=(.77*np.sin(phase)+.12*np.sin(2*phase+.15)+.06*np.sin(3*phase+.8)
         +.035*np.sin(phase + 1.3*np.sin(2*np.pi*1.2*dt)))
 lead[l:r]+=(.19*expression*timbre).astype(np.float32)

# Subtle modulated electronic halo, NOT the signature astronomical rise or Shepard fall.
halo=np.zeros((N,2),np.float32)
for k,(a,b,notes) in enumerate(scenes):
 l=int(a*SR);r=min(N,int(b*SR));tt=T[l:r];u=tt-a
 f=hz(notes[-1]+12)
 phi=2*np.pi*f*u + 2.0*np.sin(2*np.pi*.055*u+k)
 amp=fade(tt,a,b,3.7,4.3)*(.018+.008*np.sin(2*np.pi*.091*tt+k))
 s=(np.sin(phi)+.25*np.sin(2*phi)) *amp
 halo[l:r,0]+=(s*(.36+.14*k%2)).astype(np.float32)
 halo[l:r,1]+=(s*(.60-.08*k%2)).astype(np.float32)

pad=filterhp(pad,110)
dry=np.column_stack((.75*pad[:,0]+.82*lead+.68*dr+.6*halo[:,0],
                     .75*pad[:,1]+.82*lead+.68*dr+.6*halo[:,1])).astype(np.float32)
# Diffuse far-field stereo reverb, subtract low frequencies from reflections.
wet=np.zeros_like(dry)
for ch in (0,1):
 length=int(4.6*SR); ir=np.zeros(length,np.float32)
 for offset,g in ((.089,.16),(.161,.13),(.273,.11),(.401,.08),(.557,.055)):
  ir[int((offset+.015*ch)*SR)]+=g
 noise=rng.normal(0,1,length).astype(np.float32)
 noise=sosfilt(butter(1,3500,fs=SR,output='sos'),noise)
 t=np.arange(length)/SR
 ir+=.0029*(noise*np.exp(-t/1.4)*sm((t-.04)/.16)).astype(np.float32)
 wet[:,ch]=fftconvolve(dry[:,1-ch],ir,mode='full')[:N]
wet=filterhp(wet,155)
# Preserve direct sound intelligibility while keeping substantial space.
mix=filterhp(.81*dry+.76*wet,37)
mix[:SR]*=np.linspace(0,1,SR)[:,None]
mix[-int(1.6*SR):]*=np.linspace(1,0,int(1.6*SR))[:,None]
peak=np.max(np.abs(mix));mix=(mix*(.283/max(peak,1e-8))).astype(np.float32)
wav=OUT/'starswarm-round42_7-B-cosmic-motion.wav'
mp3=OUT/'starswarm-round42_7-B-cosmic-motion.mp3'
sf.write(wav,mix,SR,subtype='PCM_16')
subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(wav),'-codec:a','libmp3lame','-b:a','128k',str(mp3)],check=True)
print('Saved',mp3,'peak',peak)
