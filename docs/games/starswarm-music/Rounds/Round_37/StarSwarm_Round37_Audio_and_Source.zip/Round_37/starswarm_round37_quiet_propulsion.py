"""Star Swarm Round 37: controlled subdued-passage musical propulsion A/B.
Derived only from the original Round 31/36 procedural score, never reference audio.
A/B share exact notes, timbres, instruments and loudness. B changes only the
individual backing-voice expression during a quiet portion of the second phrase.
Requires numpy, scipy, ffmpeg and starswarm_round31_expressive_lead.py in same folder.
"""
from pathlib import Path
import numpy as np
from scipy.signal import butter, sosfiltfilt
import subprocess
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'starswarm_round31_expressive_lead.py'
SR=24000;PACE=.87;DUR=47.5;N=int(SR*DUR)
base=Path(ROOT/'starswarm_round36_two_phrases.py').read_text()
# Reuse the original phrase/harmony transformations, but not the final audio.
prefix=base.split("x=ns['render']('D')",1)[0]
# Original synthesizer voice-level performance shaping: only existing chord and
# bass voices are gently exchanged over the quieter passage.
injection='''
        if QUIET_MOTION and kind in ('field','coil','sub'):
            local_time=start+t
            region=ss((local_time-22.8)/2.2)*ss((35.0-local_time)/2.3)
            # Phrased ensemble motion, alternating handoffs between harmonic
            # groups rather than adding more voices or faster random notes.
            if kind=='sub':
                contour=.86+.14*np.cos(2*np.pi*(local_time-24.0)/5.4)
            elif kind=='field':
                contour=.81+.19*np.sin(2*np.pi*(local_time-23.2)/4.3+.35)
            else:
                contour=.82+.18*np.sin(2*np.pi*(local_time-24.2)/4.3+2.15)
            env*=1+region*(contour-1)*1.65
'''
# Inject before end-of-voice synthesis, after existing envelopes are computed.
prefix=prefix.replace("code=code.replace('macro=", "code=code.replace('macro=")
# Need inject into transformed round31 source after prefix executes. We append to
# the original code-building section right before exec(compile...).
needle="ns={'__name__':'round36_score','__file__':str(SOURCE)}"
assert needle in prefix
prefix=prefix.replace(needle,
 "code=code.replace(\"        y=(volume*x*env).astype(np.float32)\", " + repr(injection + "        y=(volume*x*env).astype(np.float32)") + ")\n"+needle)
# Quiet front melody intentionally identical in both: one soft, exploratory
# lull, with supporting voices sustaining the sense of musical direction.
# No audio from Round 36 is imported; its score is re-rendered deterministically.
post='''
x=ns['render']('D')[:,:N].astype(np.float64)
lo=sosfiltfilt(butter(3,140,fs=SR,output='sos'),x,axis=1)
x=lo*.78+(x-lo)*1.13
t=np.arange(N)/SR
knots=[(0,.58),(.5,.68),(1.6,.96),(3.3,1.14),(4.45,1.11),(5,.82),
       (5.8,1.0),(7.2,1.17),(8.85,1.10),(9.75,.82),(10.4,.92),
       (12.2,1.19),(14.2,1.06),(15.25,.78),(16.1,.93),(17.9,1.16),
       (19.0,1.08),(20.25,.76),(21.4,1.12),(22.6,.94),
       (24.1,.80),(25.5,.91),(27.0,.85),(28.3,.78),(29.6,.69),
       (30.8,.79),(32.4,.86),(34.1,.83),(35.4,1.05),(37.0,1.20),
       (38.6,.81),(40.0,1.08),(41.6,1.14),(42.6,.78),(44.1,1.09),
       (46.3,1.12),(47.5,1.04)]
pts=[(a*PACE,b) if a<=22.6 else (22.6*PACE+(a-22.6)*PACE,b) for a,b in knots]
X=np.array([q[0] for q in pts]);Y=np.array([q[1] for q in pts]);X=np.append(X,DUR);Y=np.append(Y,1.)
env=np.interp(t,X,Y)
window=np.hanning(3601);window/=window.sum()
env=np.convolve(np.pad(env,(1800,1800),mode='edge'),window,mode='valid')[:N]
x*=env[None,:]
# Same quieter passage in A/B; B differs only in the *existing supporting
# instruments' shaped voice envelopes* while the lead has room to recede.
quiet=np.clip((t-22.5)/2.5,0,1)*np.clip((35.0-t)/2.6,0,1)
x*= (1-.09*quiet)[None,:]
x*=np.clip((DUR-t)/.12,0,1)[None,:]
'''
# Avoid reusing any earlier rendered MP3 and capture deterministic PCM output.
def synth(motion):
    ns={'__file__':str(ROOT/'starswarm_round36_two_phrases.py'), '__name__':'round37_build'}
    exec(compile(prefix,str(ROOT/'starswarm_round36_two_phrases.py'),'exec'),ns)
    ns['ns']['QUIET_MOTION']=bool(motion)
    exec(compile(post,'round37_final_score','exec'),ns)
    return ns['x'].astype(np.float32)

A=synth(False); B=synth(True)
# A and B same overall RMS to avoid loudness preference confounds.
rms=lambda a:float(np.sqrt(np.mean(a.astype(np.float64)**2)))
B*=rms(A)/rms(B)
gain=min(.80/max(np.max(np.abs(A)),np.max(np.abs(B))),.095/max(rms(A),rms(B)))
for tag,sig in [('A-quiet-control',A),('B-living-undercurrent',B)]:
    target=ROOT/f'starswarm-round37-{tag}.mp3'
    cmd=['ffmpeg','-y','-loglevel','error','-f','f32le','-ar',str(SR),'-ac','2',
         '-i','pipe:0','-c:a','libmp3lame','-b:a','128k',str(target)]
    subprocess.run(cmd,input=np.ascontiguousarray((sig*gain).T,dtype='<f4').tobytes(),check=True)
    print(target.name,target.stat().st_size, 'bytes')
