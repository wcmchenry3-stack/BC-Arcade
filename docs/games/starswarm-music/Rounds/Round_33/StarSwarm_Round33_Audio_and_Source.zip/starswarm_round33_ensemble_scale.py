"""Star Swarm round 33: controlled small-versus-large sci-fi ensemble audition.

Dependencies: numpy, scipy, ffmpeg, and sibling Round 32 source.
Both recordings synthesized from scores; no third-party audio or prior MP3 read.
Run from any location; looks for Round 32 generator in adjacent ../Round_32,
then the same directory (for bundled download ZIP).
"""
from pathlib import Path
import importlib.util
import subprocess
import re
import numpy as np

HERE=Path(__file__).resolve().parent
candidates=[HERE.parent/'Round_32'/'starswarm_round32_living_neon_lead.py', HERE/'starswarm_round32_living_neon_lead.py', Path('/mnt/data/starswarm_round32_living_neon_lead.py')]
source=next((p for p in candidates if p.exists()),None)
if not source: raise FileNotFoundError('Place starswarm_round32_living_neon_lead.py next to this file or in ../Round_32')
spec=importlib.util.spec_from_file_location('round32_score',str(source)); old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
SR=old.SR; DUR=old.DUR; N=old.N

# One single original score. A = Round 32's quartet-sized rendering; B = an
# orchestrated set of several supportive instrument families, not an effects bed.
small=old.render('D').astype(np.float64)
large=small.copy()

def hz(m):return 440*2**((m-69)/12.)
def shape(x):
    x=np.clip(x,0,1);return x*x*(3-2*x)
def voice(midi,start,duration,amp,register,part,pan,seed):
    s=max(0,int(start*SR));e=min(N,int((start+duration)*SR))
    if e<=s:return
    t=np.arange(e-s)/SR
    f=hz(midi)
    # Multiple performer-like coherent partials rather than identical copies.
    slow=.0010*np.sin(2*np.pi*(.27+.017*(seed%7))*t+.61*seed)
    wander=.00042*np.sin(2*np.pi*(.77+.019*(seed%5))*t+.93*seed)
    ph=2*np.pi*np.cumsum(f*(1+slow+wander))/SR+seed*.47
    arc=shape((t-.09)/max(.2,duration*.55))*shape((duration-t)/max(.2,duration*.34))
    if register=='body':
        y=(.72*np.sin(ph)+(.13+.13*arc)*np.sin(2*ph+.24)+.095*np.sin(3.006*ph+.4))
    elif register=='halo':
        y=(.64*np.sin(ph)+(.18+.12*arc)*np.sin(2.003*ph+.3)+.07*np.sin(3.13*ph+.8))
    elif register=='low':
        y=(.82*np.sin(ph)+.21*np.sin(2*ph+.4)+.07*np.sin(3*ph+.2))
    else:
        y=.7*np.sin(ph)+.18*np.sin(2.009*ph)
    if register=='low': attack=.11;release=.35
    elif register=='halo':attack=.55;release=.65
    else: attack=.20;release=.55
    env=shape(t/attack)*shape((duration-t)/release)
    env*=.78+.25*shape(t/max(.3,duration*.65))
    # Sections breathe in subtly offset waves, but converge at the same arrivals.
    env*=.93+.07*np.sin(2*np.pi*(.24+.01*(part%7))*t+.6*seed)
    y=amp*env*y
    a=(pan+1)*np.pi/4
    large[0,s:e]+=y*np.cos(a)
    large[1,s:e]+=y*np.sin(a)

# Same Dm-Bbmaj7-Gm7-A7sus-Dm as Round 32, but 3 coordinated instrumental
# 'families': middle field choir, elevated halo, and rolling low-string energy.
harmony=[
(0,5.5,38,[57,62,65,69,74]),
(5.1,5.6,34,[58,62,65,69,74]),
(10.2,5.8,31,[55,58,62,67,74]),
(15.8,5.2,33,[57,62,64,67,76]),
(20.6,5.4,38,[57,62,65,69,74]),
]
for j,(start,dur,root,tones) in enumerate(harmony):
    # Cohesive midrange *section*, not another melody on top. Staggered divisi.
    for k,p in enumerate(tones[:4]):
        for player in range(2):
            st=start + .05*k + .045*player
            voice(p,st,max(.2,dur-.09*k),.0073,'body',j,-.65+.30*k+(.07 if player else -.07),100+j*30+k*3+player)
    # Expansive upper spectral air that slowly opens in concert with harmony.
    for k,p in enumerate([tones[1]+12,tones[3]+12]):
        voice(p,start+.24+.16*k,max(.2,dur-.35),.0060,'halo',j,-.48 if k==0 else .52,200+j*5+k)
    # Urgent bass movement that supports the sustained center, not marching drums.
    if j!=4:
        for k,(off,iv) in enumerate([(.4,0),(1.6,7),(2.8,12),(3.9,7)]):
            voice(root+iv,start+off,.72,.0095,'low',j,(-.25 if k%2 else .22),300+j*7+k)
    # Architectural rise in the last third: continuous section dynamics, no random SFX.

# Gentle room propagation of the *new* ensemble (main Round 32 room unchanged).
new=large-small
for ch in range(2):
    for delay,gain in [(.17,.06),(.51,.035)]:
        lag=int((delay+.025*ch)*SR)
        large[ch,lag:]+=gain*new[1-ch,:-lag]

# One common overall gain, then perceptual loudness match of each variant.
peak=max(np.max(np.abs(small)),np.max(np.abs(large)))
common=.81/max(peak,.00001)


def encode(name,signal,additional_db=0):
    path=HERE/name
    x=np.ascontiguousarray((signal*common*10**(additional_db/20)).T,dtype='<f4')
    subprocess.run(['ffmpeg','-y','-loglevel','error','-f','f32le','-ar',str(SR),'-ac','2','-i','pipe:0','-c:a','libmp3lame','-b:a','128k',str(path)],input=x.tobytes(),check=True)
    return path

def lufs(path):
    p=subprocess.run(['ffmpeg','-hide_banner','-i',str(path),'-filter_complex','ebur128=peak=true','-f','null','-'],capture_output=True,text=True,check=True)
    found=re.findall(r'Integrated loudness:\s*I:\s*([-\d.]+) LUFS',p.stderr)
    return float(found[-1])

if __name__=='__main__':
    pa=encode('starswarm-round33-A-small-ensemble-control.mp3',small)
    pb=encode('starswarm-round33-B-large-cinematic-ensemble.mp3',large)
    la,lb=lufs(pa),lufs(pb)
    # B deliberately matched to A so the 'bigger' ensemble is not simply louder.
    pb=encode(pb.name,large,la-lb)
    print('small',pa.name,pa.stat().st_size,lufs(pa))
    print('large',pb.name,pb.stat().st_size,lufs(pb))
