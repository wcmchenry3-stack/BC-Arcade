import subprocess,numpy as np
from scipy.signal import stft,find_peaks
from pathlib import Path
SR=16000
P=Path('/mnt/data')
sets={
 'BG1 opening':('starswarm-bg-1.mp3',0,22),
 'BG1 rise':('starswarm-bg-1.mp3',47,64),
 'BG2 chorus':('starswarm-bg-2.mp3',66,86),
 'R23 astronomical':('starswarm-round23-integrated-rough.mp3',85,109),
 'R23 swarm':('starswarm-round23-integrated-rough.mp3',158,182),
 'R18 gathering chorus':('starswarm-round18-A-gathering-chorus.mp3',12,36),
 'R20 astronomical':('starswarm-round20-A-astronomical-spotlight.mp3',9,33),
 'R30 opening':('starswarm-round30-C-harmonic-electromagnetic.mp3',0,22),
 'R31 opening':('starswarm-round31-D-expressive-electromagnetic.mp3',0,22),
 'R32 opening':('starswarm-round32-E-living-neon-lead.mp3',0,22),
 'R33 bigger':('starswarm-round33-B-large-cinematic-ensemble.mp3',0,22)
}
def decode(name,start,end):
 b=subprocess.check_output(['ffmpeg','-nostdin','-loglevel','error','-ss',str(start),'-i',str(P/name),'-t',str(end-start),'-ac','2','-ar',str(SR),'-f','f32le','pipe:1'])
 return np.frombuffer(b,dtype='<f4').reshape(-1,2)
def analyze(x):
 n=len(x); y=x.mean(axis=1)
 hop=SR//2; chunks=np.array([y[i:i+hop] for i in range(0,n-hop+1,hop)])
 r=np.sqrt((chunks**2).mean(axis=1));db=20*np.log10(r+1e-9)
 # typical envelope changes and 10-90 dB span
 FFT=np.abs(np.fft.rfft(chunks*np.hanning(hop),axis=1));f=np.fft.rfftfreq(hop,1/SR)
 pow=FFT**2
 centroid=(pow*f).sum(axis=1)/(pow.sum(axis=1)+1e-12)
 low=pow[:,f<80].sum(axis=1)/(pow.sum(axis=1)+1e-12)
 pres=pow[:,(f>=500)&(f<3000)].sum(axis=1)/(pow.sum(axis=1)+1e-12)
 high=pow[:,f>=4000].sum(axis=1)/(pow.sum(axis=1)+1e-12)
 flux=np.maximum(0,np.diff(FFT/(np.linalg.norm(FFT,axis=1,keepdims=True)+1e-12),axis=0)).sum(axis=1).mean()
 return dict(rmsdb=round(float(20*np.log10(np.sqrt((x*x).mean())+1e-9)),1),first2=round(float(db[:4].mean()),1),next6=round(float(db[4:16].mean()),1),last6=round(float(db[-12:].mean()),1),dyn90_10=round(float(np.percentile(db,90)-np.percentile(db,10)),1),median_05s_change=round(float(np.median(np.abs(np.diff(db)))),1),centroid=round(float(np.median(centroid))),sub80=round(float(np.median(low)*100),2),presence=round(float(np.median(pres)*100),1),above4k=round(float(np.median(high)*100),2),flux=round(float(flux),2),stereo_corr=round(float(np.corrcoef(x.T)[0,1]),2),rms_series=[round(float(v),1) for v in db])
import json
out={}
for name,(file,s,e) in sets.items():
 x=decode(file,s,e);out[name]=analyze(x)
 print(name, {k:v for k,v in out[name].items() if k!='rms_series'})
(P/'starswarm_round34_audio_measurements.json').write_text(json.dumps({'method':'ffmpeg decode 16k stereo; mono 0.5s windows; uncalibrated relative dynamics, NOT controlled loudness test', 'metrics':out},indent=2))
