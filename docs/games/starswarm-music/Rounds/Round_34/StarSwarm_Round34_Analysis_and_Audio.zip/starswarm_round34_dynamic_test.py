"""Round 34 diagnostic: tested dynamic/harmonic performance of existing original Round31 theme.
No copyrighted/reference MP3 source is rendered or sampled. Uses original project-generated
Round 31 procedural source to preserve exact melodic composition in both versions.
A = same unaltered small-ensemble score; B = score with gentle musical section automation,
bass masking adjustment and articulated harmonic arrivals; no new musical notes added.
"""
from pathlib import Path
import subprocess
import importlib.util
import numpy as np
from scipy.signal import butter,sosfiltfilt

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('round31', ROOT/'starswarm_round31_expressive_lead.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
sr=mod.SR
x=mod.render('D').copy()
# 22 s, ensures both have the exact same notes and original arrangement.
N=int(sr*22)
a=x[:,:N].copy();t=np.arange(N)/sr

# Gentle register redistribution: preserve bass presence but free the melodic mid-band.
low=sosfiltfilt(butter(3,140,fs=sr,output='sos'),a,axis=1)
mid=a-low
# This is not adding instruments. Controlled rebalancing 0.78x bass/1.13x mids.
b=low*.78+mid*1.13

# Section-directed expressive gesture: rise, meaningful release just before chord changes,
# coordinated swell at each new harmony; musical energy is an arc, not fixed level.
points=[(0,.58),(.5,.68),(1.6,.96),(3.3,1.14),(4.45,1.11),(5.0,.82),
        (5.8,1.00),(7.2,1.17),(8.85,1.10),(9.75,.82),
        (10.4,.92),(12.2,1.19),(14.2,1.06),(15.25,.78),
        (16.1,.93),(17.9,1.16),(19.0,1.08),(20.25,.76),(21.4,1.12),(22,.98)]
xt=np.array([q[0] for q in points]);yt=np.array([q[1] for q in points])
raw=np.interp(t,xt,yt)
# 150 ms smoothing eliminates segmented gain changes; preserve energy trajectory.
k=int(.15*sr);k+=1-k%2
ker=np.hanning(k);ker/=ker.sum()
env=np.convolve(np.pad(raw,(k//2,k//2),mode='edge'),ker,mode='valid')[:N]
b*=env[None,:]
# Both test files gain-match to same integrated energy; do not make B artificially louder.
energy=lambda sig:float(np.sqrt(np.mean(sig.astype('float64')**2)))
g=.11/max(energy(a),energy(b))
# additionally B rms normalized to A before global gain
b*=energy(a)/energy(b)
peak=max(float(np.max(abs(a))),float(np.max(abs(b))))
g=min(g,.90/peak)

for name,sig in [('starswarm-round34-A-original-score-control.mp3',a),('starswarm-round34-B-directed-musical-force.mp3',b)]:
    cmd=['ffmpeg','-y','-loglevel','error','-f','f32le','-ac','2','-ar',str(sr),'-i','pipe:0','-c:a','libmp3lame','-b:a','128k',str(ROOT/name)]
    subprocess.run(cmd,input=np.ascontiguousarray((sig*g).T,dtype='<f4').tobytes(),check=True)
    print(name, (ROOT/name).stat().st_size)
